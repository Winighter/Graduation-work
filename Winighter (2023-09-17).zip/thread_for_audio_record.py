import os
from PyQt5.QtCore import *


class Worker(QRunnable):

    def __init__(self, fn):
        super(Worker, self).__init__()
        self.fn = fn
        self.originating_PID = os.getpid()
        self._running = True

    @pyqtSlot()
    def run(self):
        self.fn()