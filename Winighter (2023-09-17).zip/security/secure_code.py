import pyotp
from hashlib import sha256

Block = []

class SecurityManager:
    def __init__(self):
        print('Run Security Manager')
        # self.add_block(data='data')

    def create_hash(data:str,prevHash:bytes) -> bytes:
        return sha256(data.encode() + prevHash).hexdigest()

    def add_block(self,data:str):
        current_hash = SecurityManager.create_hash('First Data',b'')
        Block.append((data,b''.decode(),current_hash))

        for i in range(100):
            _,_,prev_hash = Block[-1]
            prev_hash = bytes(prev_hash,'utf-8')
            current_hash = SecurityManager.create_hash(data,prev_hash)
            Block.append((data,prev_hash.decode(),current_hash))
            # print(f'\n블록 {i}  {data}  {prev_hash.decode()}  {current_hash}')
            
        
    def get_otpCode(self):
        otp_value = pyotp.TOTP(pyotp.random_base32()).now()
        otp_value = otp_value[0:3]+'-'+otp_value[3:]
        return otp_value