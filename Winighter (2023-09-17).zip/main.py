import sys,keyboard,threading
from PySide2.QtWidgets import QMainWindow

from modules import *
from security import *

widgets = None
counter = 1
TAB = False

class LoginScreen(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.login_ui = Ui_LoginScreen()
        self.login_ui.setupUi(self)
        Ui_Functions.uiLoginDefinitions(self)

        self.login_ui.Btn_Login.clicked.connect(self.onLogin)
        self.login_ui.Btn_Approve.clicked.connect(self.onLogin)
        self.login_ui.Btn_Deny.clicked.connect(self.onLogin)
        self.login_ui.Btn_forgot_pw.clicked.connect(self.onLogin)
        self.login_ui.Btn_Register.clicked.connect(self.onLogin)
        self.login_ui.Btn_backtoLogin.clicked.connect(self.onLogin)
        self.login_ui.Btn_Continue.clicked.connect(self.onLogin)

        self.show()
        self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)


    def onLogin(self):
        # GET BUTTON CLICKED
        btn = self.sender()
        btnName = btn.objectName()
        if btnName == "Btn_Login":
            id = self.login_ui.LineEdit_ID.text()
            pw = self.login_ui.LineEdit_PW.text()

            if id == '' and pw == '':
                Ui_Functions.loginScreenState(self,0)
                self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_otp)
                self.otp_code = SecurityManager.get_otpCode(self)
                self.login_ui.label_TOTP.setText(self.otp_code)

                self.timer = QTimer()
                self.timer.timeout.connect(self.update)
                self.timer.start(1000)
            else:
                Ui_Functions.loginScreenState(self,1)

        if btnName == "Btn_Approve":
            self.timer.stop()
            self.close()
            Tray.run_tray()
            MainWindow()
            
            
        if btnName == "Btn_Deny":
            pass

        if btnName == "Btn_forgot_pw":
            self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_FindPassword)

        if btnName == "Btn_Register":
            self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_Register)

        if btnName == "Btn_backtoLogin":
            self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)

        if btnName == "Btn_Continue":
            policy1 = self.login_ui.checkBox_policy1.isChecked()
            policy2 = self.login_ui.checkBox_policy2.isChecked()
            policy3 = self.login_ui.checkBox_policy3.isChecked()
            if (policy1 and policy2 and policy3):
                self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)
                self.login_ui.checkBox_policy1.toggle()
                self.login_ui.checkBox_policy2.toggle()
                self.login_ui.checkBox_policy3.toggle()

    def update(self):
        global counter
        self.login_ui.label_totp_remaining_time.setText("%ss"%(10-counter))
        if counter >= 10:
            counter = 0
            self.login_ui.label_totp_remaining_time.setText("10s")
            self.login_ui.label_TOTP.setText(SecurityManager.get_otpCode(self))
        counter += 1

    def mousePressEvent(self, event):
        # SET DRAG POS WINDOW
        self.dragPos = event.globalPos()


class MainWindow(QMainWindow,QWidget):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        global widgets
        widgets = self.ui
        
        Ui_Functions.uiDefaultSet(self)

        # widgets.frame_Main.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        # Top Buttons

        # Left Page Button
        widgets.Btn_Home.clicked.connect(self.onClick)
        widgets.Btn_myTasks.clicked.connect(self.onClick)
        # widgets.Btn_.clicked.connect(self.onClick)
        # widgets.Btn_.clicked.connect(self.onClick)
        widgets.Btn_Developer.clicked.connect(self.onClick)

        # Left Secret Page Button
        widgets.Btn_sHome.clicked.connect(self.onClick)
        widgets.Btn_sPage_2.clicked.connect(self.onClick)
        widgets.Btn_sPage_3.clicked.connect(self.onClick)
        widgets.Btn_sPage_4.clicked.connect(self.onClick)
        widgets.Btn_sPage_5.clicked.connect(self.onClick)

        # Left Button
        widgets.Btn_SecretMode.clicked.connect(lambda: Ui_Functions.toggleSecretMode(self))

        # Left Toggle Button
        widgets.Btn_Settings.clicked.connect(lambda: Ui_Functions.toggleFrameSetting(self, True))

        # Right Toggle Button
        widgets.Btn_Notifications.clicked.connect(lambda: Ui_Functions.toggleFrameRight(self, True))

        # Show Real Time Clock
        self.set_clock()

        # Show UI
        self.show()


    def onClick(self):
        btn = self.sender()
        btnName = btn.objectName()

        if btnName == 'Btn_Home':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_Home)

        if btnName == 'Btn_myTasks':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_2)

        # if btnName == 'Btn_':
        #     widgets.stackedWidget_Main.setCurrentWidget(widgets.page_3)

        # if btnName == 'Btn_':
        #     widgets.stackedWidget_Main.setCurrentWidget(widgets.page_4)

        if btnName == 'Btn_Developer':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_5)
        
        if btnName == 'Btn_sHome':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sHome)

        if btnName == 'Btn_sPage_2':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_2)

        if btnName == 'Btn_sPage_3':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_3)

        if btnName == 'Btn_sPage_4':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_4)

        if btnName == 'Btn_sPage_5':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_5)

        Ui_Functions.toggleFrameLeft(self, True)

    def mouseMoveEvent(self, event):
        pass

    ### Left Top Bar CLOCK #############################
    # Clock 1
    def set_clock(self):
        clock_timer = QTimer(self)
        clock_timer.timeout.connect(self.show_time)
        clock_timer.start(1000)

    # Clock 2
    def show_time(self):
        current_time = QTime.currentTime()
        label_time = current_time.toString("hh:mm:ss")
        widgets.label_Clock.setText(label_time)

    def initUI(self):
        self.setWindowIcon(QIcon('004.jpg'))
        self.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    appicon = QIcon("004.jpg")
    login = LoginScreen()
    sys.exit(app.exec_())

# pyside2-rcc resources.qrc -o resources_rc.py

# from . resources_rc import *