import pystray,threading
from PIL import Image

class Tray:
	image = Image.open("004.jpg")
	def after_click(icon, query):
		if str(query) == "Menu 1":
			print("Menu \
		1")
			# icon.stop()
		elif str(query) == "Menu 2":
			print("Menu \
		2")
			# icon.stop()
		elif str(query) == "Menu 3":
			print("Menu \
		3")
		elif str(query) == "Exit":
			icon.stop()


	icon = pystray.Icon("GFG", image, "Winighter is running",
						menu=pystray.Menu(
		pystray.MenuItem("Menu 1",after_click),
		
		pystray.MenuItem("Menu 2",after_click),
		
		pystray.MenuItem("Menu 3",after_click),
		
		pystray.MenuItem("Exit", after_click)))
	
	def run_icon():
		Tray.icon.run()

	def run_tray():
		runtray = threading.Thread(target=Tray.run_icon)
		runtray.daemon = True
		runtray.start()