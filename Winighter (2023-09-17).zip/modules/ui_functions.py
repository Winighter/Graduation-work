from main import *

S = False
TAB = False
STATE = False

class Ui_Functions(MainWindow):

    def uiDefaultSet(self):

        # Standard Title Bar
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        self.setWindowIcon(QIcon('004.jpg'))
        

        # Minimize Button
        self.ui.Btn_Minimize.clicked.connect(lambda:self.showMinimized())
        
        # Maximize & Resotre Button
        self.ui.Btn_MaximizeRestore.clicked.connect(lambda:Ui_Functions.maximize_restore(self))
        
        # Minimize Button
        self.ui.Btn_Close.clicked.connect(lambda:self.close())

    # Maximize & Resotre Function
    def maximize_restore(self):
        global STATE
        status = STATE
        if status == False:
            STATE = True
            self.showMaximized()
            self.ui.Btn_MaximizeRestore.setStyleSheet('background-image: url(:/icons/images/icons/cil-window-restore.png);')
        else:
            STATE = False
            self.showNormal()
            self.ui.Btn_MaximizeRestore.setStyleSheet('background-image: url(:/icons/images/icons/icon_maximize.png);')

    # Toggle Extra Left Menu
    def toggleFrameLeft(self, enable):
        if enable:
            width = self.ui.frame_Left.width()
            standard = 60
            maxExtend = 220
            
            if width == 60:
                widthExtended = maxExtend
            else:
                widthExtended = standard

            self.animation = QPropertyAnimation(self.ui.frame_Left, b"minimumWidth")
            self.animation.setDuration(200)
            self.animation.setStartValue(width)
            self.animation.setEndValue(widthExtended)
            self.animation.setEasingCurve(QEasingCurve.InOutQuart)
            self.animation.start()

    # Toggle Extra Right Menu
    def toggleFrameRight(self, enable):
        if enable:
            width = self.ui.frame_Right.width()
            standard = 0
            maxExtend = 260
            
            if width == 0:
                widthExtended = maxExtend
            else:
                widthExtended = standard

            self.animation = QPropertyAnimation(self.ui.frame_Right, b"minimumWidth")
            self.animation.setDuration(200)
            self.animation.setStartValue(width)
            self.animation.setEndValue(widthExtended)
            self.animation.setEasingCurve(QEasingCurve.InOutQuart)
            self.animation.start()

    # Toggle Extra Setting Menu
    def toggleFrameSetting(self, enable):
        if enable:
            width = self.ui.frame_SettingMenu.width()
            standard = 0
            maxExtend = 250
            
            if width == 0:
                widthExtended = maxExtend
            else:
                widthExtended = standard

            self.animation = QPropertyAnimation(self.ui.frame_SettingMenu, b"minimumWidth")
            self.animation.setDuration(200)
            self.animation.setStartValue(width)
            self.animation.setEndValue(widthExtended)
            self.animation.setEasingCurve(QEasingCurve.InOutQuart)
            self.animation.start()

    #  SECRET TOGGLE BUTTON 
    def toggleSecretMode(self):  
        global S
        if S == False:
            S = True
            self.ui.Btn_SecretMode.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-heart.png);")
            thread = threading.Thread(target=Ui_Functions.get_keyboard_input_value,args=(self,))
            thread.daemon = True
            thread.start()
        else:
            S = False
            Ui_Functions.toggleLeftMenuTab(self)
            self.ui.Btn_SecretMode.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-ban.png);")


    # SECRET MODE EVENT
    def toggleLeftMenuTab(self):
        global TAB

        if TAB == False and S == True:
            TAB = True
            self.ui.label_Mode.setText("SECRET MODE")
            self.ui.stackedWidget_Main.setCurrentWidget(self.ui.page_sHome)
            self.ui.stackedWidget_Left.setCurrentWidget(self.ui.page_LeftMenu_2)
            self.ui.frame_ProfileUser.setStyleSheet(u"background-image: url(:/images/images/images/004.jpg);")

        elif TAB == True:
            TAB = False
            self.ui.label_Mode.setText("")
            self.ui.stackedWidget_Main.setCurrentWidget(self.ui.page_Home)
            self.ui.stackedWidget_Left.setCurrentWidget(self.ui.page_LeftMenu_1)
            self.ui.frame_ProfileUser.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-user.png);")

    def open_file(self):
        fileName = QFileDialog.getOpenFileNames(self, "Open file", "./")

    def add_save(self):
        FileSave = QFileDialog.getSaveFileNames(self, "Save file", "./")

    def find_folder(self):
        FileFolder = QFileDialog.getExistingDirectory(self, "Find Folder")

    def uiLoginDefinitions(self):
        self.setWindowFlags(Qt.FramelessWindowHint)

        self.setWindowIcon(QIcon('004.jpg'))

        def moveWindow(event):
            if event.buttons() == Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                # event.accept()
        self.login_ui.bgApp.mouseMoveEvent = moveWindow

        # MINIMIZE
        self.login_ui.Btn_Minimize.clicked.connect(lambda: self.showMinimized())

        # CLOSE APPLICATION
        self.login_ui.Btn_Close.clicked.connect(lambda: self.close())


    def loginScreenState(self,bool):
        if bool == 0:
            self.login_ui.label_login_state.setText("")
        else:
            self.login_ui.label_login_state.setText("Incorrect Username or Password")


    def get_keyboard_input_value(self):
        global running
        running = True
        emptyBox = ""
        sCode = "upupdowndownleftrightleftrightbaenter"
        not_pressed = True
        while running:
            input = keyboard.read_key(suppress = True)
            if sCode in emptyBox:
                emptyBox = ""
                running = False
                Ui_Functions.toggleLeftMenuTab(self)
            else:
                if not_pressed:
                    emptyBox = emptyBox + input
                    not_pressed = False
                else:
                    not_pressed = True