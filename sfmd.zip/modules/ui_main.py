# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainnSYjaY.ui'
##
## Created by: Qt User Interface Compiler version 6.9.0
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QFrame, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QMainWindow, QPushButton,
    QSizePolicy, QStackedWidget, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(940, 560)
        MainWindow.setMinimumSize(QSize(940, 560))
        MainWindow.setStyleSheet(u"")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.verticalLayout = QVBoxLayout(self.centralwidget)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(self.centralwidget)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.Shape.NoFrame)
        self.frame.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout = QHBoxLayout(self.frame)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame_2 = QFrame(self.frame)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setMinimumSize(QSize(60, 0))
        self.frame_2.setMaximumSize(QSize(16777215, 16777215))
        self.frame_2.setStyleSheet(u"background-color: rgb(213, 213, 213);")
        self.frame_2.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_2.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_2)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.frame_11 = QFrame(self.frame_2)
        self.frame_11.setObjectName(u"frame_11")
        self.frame_11.setMaximumSize(QSize(16777215, 60))
        self.frame_11.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_11.setFrameShadow(QFrame.Shadow.Raised)

        self.verticalLayout_7.addWidget(self.frame_11)

        self.frame_12 = QFrame(self.frame_2)
        self.frame_12.setObjectName(u"frame_12")
        self.frame_12.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_12.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.frame_12)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.frame_13 = QFrame(self.frame_12)
        self.frame_13.setObjectName(u"frame_13")
        self.frame_13.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_13.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.frame_13)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.Btn_Home = QPushButton(self.frame_13)
        self.Btn_Home.setObjectName(u"Btn_Home")
        self.Btn_Home.setMinimumSize(QSize(0, 60))
        self.Btn_Home.setMaximumSize(QSize(60, 16777215))

        self.verticalLayout_9.addWidget(self.Btn_Home)

        self.Btn_Search = QPushButton(self.frame_13)
        self.Btn_Search.setObjectName(u"Btn_Search")
        self.Btn_Search.setMinimumSize(QSize(0, 60))
        self.Btn_Search.setMaximumSize(QSize(60, 16777215))

        self.verticalLayout_9.addWidget(self.Btn_Search)

        self.Btn_Data = QPushButton(self.frame_13)
        self.Btn_Data.setObjectName(u"Btn_Data")
        self.Btn_Data.setMinimumSize(QSize(0, 60))
        self.Btn_Data.setMaximumSize(QSize(60, 16777215))

        self.verticalLayout_9.addWidget(self.Btn_Data)


        self.verticalLayout_8.addWidget(self.frame_13, 0, Qt.AlignmentFlag.AlignTop)

        self.frame_14 = QFrame(self.frame_12)
        self.frame_14.setObjectName(u"frame_14")
        self.frame_14.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_14.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_10 = QVBoxLayout(self.frame_14)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.Btn_Button = QPushButton(self.frame_14)
        self.Btn_Button.setObjectName(u"Btn_Button")
        self.Btn_Button.setMinimumSize(QSize(0, 60))
        self.Btn_Button.setMaximumSize(QSize(60, 16777215))

        self.verticalLayout_10.addWidget(self.Btn_Button)

        self.Btn_Setting = QPushButton(self.frame_14)
        self.Btn_Setting.setObjectName(u"Btn_Setting")
        self.Btn_Setting.setMinimumSize(QSize(0, 60))
        self.Btn_Setting.setMaximumSize(QSize(60, 16777215))

        self.verticalLayout_10.addWidget(self.Btn_Setting)


        self.verticalLayout_8.addWidget(self.frame_14, 0, Qt.AlignmentFlag.AlignBottom)


        self.verticalLayout_7.addWidget(self.frame_12)


        self.horizontalLayout.addWidget(self.frame_2)

        self.frame_3 = QFrame(self.frame)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_3.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame_3)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.frame_5 = QFrame(self.frame_3)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setMaximumSize(QSize(16777215, 35))
        self.frame_5.setStyleSheet(u"background-color: rgb(79, 79, 79);")
        self.frame_5.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_5.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_5)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.frame_7 = QFrame(self.frame_5)
        self.frame_7.setObjectName(u"frame_7")
        self.frame_7.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_7.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_3 = QVBoxLayout(self.frame_7)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(10, 0, 0, 0)
        self.label_description = QLabel(self.frame_7)
        self.label_description.setObjectName(u"label_description")

        self.verticalLayout_3.addWidget(self.label_description)


        self.horizontalLayout_2.addWidget(self.frame_7)

        self.frame_8 = QFrame(self.frame_5)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setStyleSheet(u"background-color: rgb(48, 48, 48);")
        self.frame_8.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_8.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_8)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.Btn_Profile = QPushButton(self.frame_8)
        self.Btn_Profile.setObjectName(u"Btn_Profile")
        self.Btn_Profile.setMinimumSize(QSize(35, 35))
        self.Btn_Profile.setMaximumSize(QSize(35, 35))

        self.horizontalLayout_3.addWidget(self.Btn_Profile)

        self.Btn_Minimize = QPushButton(self.frame_8)
        self.Btn_Minimize.setObjectName(u"Btn_Minimize")
        self.Btn_Minimize.setMinimumSize(QSize(35, 35))
        self.Btn_Minimize.setMaximumSize(QSize(35, 35))

        self.horizontalLayout_3.addWidget(self.Btn_Minimize)

        self.Btn_MaximizeRestore = QPushButton(self.frame_8)
        self.Btn_MaximizeRestore.setObjectName(u"Btn_MaximizeRestore")
        self.Btn_MaximizeRestore.setMinimumSize(QSize(35, 35))
        self.Btn_MaximizeRestore.setMaximumSize(QSize(35, 35))

        self.horizontalLayout_3.addWidget(self.Btn_MaximizeRestore)

        self.Btn_Close = QPushButton(self.frame_8)
        self.Btn_Close.setObjectName(u"Btn_Close")
        self.Btn_Close.setMinimumSize(QSize(35, 35))
        self.Btn_Close.setMaximumSize(QSize(35, 35))

        self.horizontalLayout_3.addWidget(self.Btn_Close)


        self.horizontalLayout_2.addWidget(self.frame_8, 0, Qt.AlignmentFlag.AlignRight)


        self.verticalLayout_2.addWidget(self.frame_5)

        self.frame_4 = QFrame(self.frame_3)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_4.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.frame_4)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget = QStackedWidget(self.frame_4)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.page_Home = QWidget()
        self.page_Home.setObjectName(u"page_Home")
        self.page_Home.setStyleSheet(u"background-color: rgb(126, 126, 126);")
        self.verticalLayout_12 = QVBoxLayout(self.page_Home)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.frame_16 = QFrame(self.page_Home)
        self.frame_16.setObjectName(u"frame_16")
        self.frame_16.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_16.setFrameShadow(QFrame.Shadow.Raised)

        self.verticalLayout_12.addWidget(self.frame_16)

        self.stackedWidget.addWidget(self.page_Home)
        self.page_Search = QWidget()
        self.page_Search.setObjectName(u"page_Search")
        self.verticalLayout_11 = QVBoxLayout(self.page_Search)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.frame_15 = QFrame(self.page_Search)
        self.frame_15.setObjectName(u"frame_15")
        self.frame_15.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_15.setFrameShadow(QFrame.Shadow.Raised)
        self.lineEdit_Search = QLineEdit(self.frame_15)
        self.lineEdit_Search.setObjectName(u"lineEdit_Search")
        self.lineEdit_Search.setGeometry(QRect(70, 60, 541, 22))
        self.Btn_SearchData = QPushButton(self.frame_15)
        self.Btn_SearchData.setObjectName(u"Btn_SearchData")
        self.Btn_SearchData.setGeometry(QRect(620, 60, 75, 24))
        self.Btn_RemoveData = QPushButton(self.frame_15)
        self.Btn_RemoveData.setObjectName(u"Btn_RemoveData")
        self.Btn_RemoveData.setGeometry(QRect(780, 60, 75, 24))
        self.Btn_AddData = QPushButton(self.frame_15)
        self.Btn_AddData.setObjectName(u"Btn_AddData")
        self.Btn_AddData.setGeometry(QRect(700, 60, 75, 24))

        self.verticalLayout_11.addWidget(self.frame_15)

        self.stackedWidget.addWidget(self.page_Search)
        self.page_Database = QWidget()
        self.page_Database.setObjectName(u"page_Database")
        self.verticalLayout_5 = QVBoxLayout(self.page_Database)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_9 = QFrame(self.page_Database)
        self.frame_9.setObjectName(u"frame_9")
        self.frame_9.setMinimumSize(QSize(0, 80))
        self.frame_9.setMaximumSize(QSize(16777215, 80))
        self.frame_9.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_9.setFrameShadow(QFrame.Shadow.Raised)
        self.lineEdit_path = QLineEdit(self.frame_9)
        self.lineEdit_path.setObjectName(u"lineEdit_path")
        self.lineEdit_path.setGeometry(QRect(50, 20, 491, 22))
        self.Btn_Open = QPushButton(self.frame_9)
        self.Btn_Open.setObjectName(u"Btn_Open")
        self.Btn_Open.setGeometry(QRect(560, 20, 75, 24))

        self.verticalLayout_5.addWidget(self.frame_9)

        self.frame_10 = QFrame(self.page_Database)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setStyleSheet(u"background-color: rgb(127, 127, 127);")
        self.frame_10.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_10.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.frame_10)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(10, 10, 10, 10)
        self.tableWidget = QTableWidget(self.frame_10)
        if (self.tableWidget.columnCount() < 5):
            self.tableWidget.setColumnCount(5)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(4, __qtablewidgetitem4)
        if (self.tableWidget.rowCount() < 11):
            self.tableWidget.setRowCount(11)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, __qtablewidgetitem7)
        __qtablewidgetitem8 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, __qtablewidgetitem8)
        __qtablewidgetitem9 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(4, __qtablewidgetitem9)
        __qtablewidgetitem10 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(5, __qtablewidgetitem10)
        __qtablewidgetitem11 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(6, __qtablewidgetitem11)
        __qtablewidgetitem12 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(7, __qtablewidgetitem12)
        __qtablewidgetitem13 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(8, __qtablewidgetitem13)
        __qtablewidgetitem14 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(9, __qtablewidgetitem14)
        __qtablewidgetitem15 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(10, __qtablewidgetitem15)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setFrameShape(QFrame.Shape.NoFrame)

        self.verticalLayout_6.addWidget(self.tableWidget)


        self.verticalLayout_5.addWidget(self.frame_10)

        self.stackedWidget.addWidget(self.page_Database)

        self.verticalLayout_4.addWidget(self.stackedWidget)


        self.verticalLayout_2.addWidget(self.frame_4)

        self.frame_6 = QFrame(self.frame_3)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setMinimumSize(QSize(0, 25))
        self.frame_6.setMaximumSize(QSize(16777215, 16777215))
        self.frame_6.setStyleSheet(u"background-color: rgb(186, 186, 186);")
        self.frame_6.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_6.setFrameShadow(QFrame.Shadow.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.frame_17 = QFrame(self.frame_6)
        self.frame_17.setObjectName(u"frame_17")
        self.frame_17.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_17.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.frame_17)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(10, 0, 0, 0)
        self.label_2 = QLabel(self.frame_17)
        self.label_2.setObjectName(u"label_2")

        self.verticalLayout_13.addWidget(self.label_2)


        self.horizontalLayout_4.addWidget(self.frame_17)

        self.frame_18 = QFrame(self.frame_6)
        self.frame_18.setObjectName(u"frame_18")
        self.frame_18.setFrameShape(QFrame.Shape.NoFrame)
        self.frame_18.setFrameShadow(QFrame.Shadow.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.frame_18)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 10, 0)
        self.label_3 = QLabel(self.frame_18)
        self.label_3.setObjectName(u"label_3")

        self.verticalLayout_14.addWidget(self.label_3, 0, Qt.AlignmentFlag.AlignRight)


        self.horizontalLayout_4.addWidget(self.frame_18)


        self.verticalLayout_2.addWidget(self.frame_6)


        self.horizontalLayout.addWidget(self.frame_3)


        self.verticalLayout.addWidget(self.frame)

        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)

        self.stackedWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.Btn_Home.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.Btn_Search.setText(QCoreApplication.translate("MainWindow", u"Search", None))
        self.Btn_Data.setText(QCoreApplication.translate("MainWindow", u"Data", None))
        self.Btn_Button.setText(QCoreApplication.translate("MainWindow", u"Button", None))
        self.Btn_Setting.setText(QCoreApplication.translate("MainWindow", u"Setting", None))
        self.label_description.setText("")
        self.Btn_Profile.setText(QCoreApplication.translate("MainWindow", u"P", None))
        self.Btn_Minimize.setText(QCoreApplication.translate("MainWindow", u"_", None))
        self.Btn_MaximizeRestore.setText(QCoreApplication.translate("MainWindow", u"\u3141", None))
        self.Btn_Close.setText(QCoreApplication.translate("MainWindow", u"X", None))
        self.Btn_SearchData.setText(QCoreApplication.translate("MainWindow", u"Search", None))
        self.Btn_RemoveData.setText(QCoreApplication.translate("MainWindow", u"Remove", None))
        self.Btn_AddData.setText(QCoreApplication.translate("MainWindow", u"Add", None))
        self.Btn_Open.setText(QCoreApplication.translate("MainWindow", u"Open", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem4 = self.tableWidget.horizontalHeaderItem(4)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem5 = self.tableWidget.verticalHeaderItem(0)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem6 = self.tableWidget.verticalHeaderItem(1)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem7 = self.tableWidget.verticalHeaderItem(2)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem8 = self.tableWidget.verticalHeaderItem(3)
        ___qtablewidgetitem8.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem9 = self.tableWidget.verticalHeaderItem(4)
        ___qtablewidgetitem9.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem10 = self.tableWidget.verticalHeaderItem(5)
        ___qtablewidgetitem10.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem11 = self.tableWidget.verticalHeaderItem(6)
        ___qtablewidgetitem11.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem12 = self.tableWidget.verticalHeaderItem(7)
        ___qtablewidgetitem12.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem13 = self.tableWidget.verticalHeaderItem(8)
        ___qtablewidgetitem13.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem14 = self.tableWidget.verticalHeaderItem(9)
        ___qtablewidgetitem14.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem15 = self.tableWidget.verticalHeaderItem(10)
        ___qtablewidgetitem15.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"TextLabel", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"1.0.0v", None))
    # retranslateUi

