import sys
import os
import pickle

# IMPORT / GUI AND MODULES AND WIDGETS
# ///////////////////////////////////////////////////////////////
from modules import *

# SET AS GLOBAL WIDGETS
# ///////////////////////////////////////////////////////////////
widgets = None

class MainWindow(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)

        # SET AS GLOBAL WIDGETS
        # ///////////////////////////////////////////////////////////////
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        global widgets
        widgets = self.ui

        # APP NAME
        # ///////////////////////////////////////////////////////////////
        title = "SFMD"
        description = "SFMD APP - Secret File Management Database."

        # APPLY TEXTS
        self.setWindowTitle(title)
        widgets.label_description.setText(description)

        # SET UI DEFINITIONS
        # ///////////////////////////////////////////////////////////////
        UIFunctions.uiDefinitions(self)

        widgets.Btn_Open.clicked.connect(self.open_file)

        widgets.Btn_SearchData.clicked.connect(self.load_data)
        # widgets.Btn_AddData.clicked.connect(self.add_data)
        widgets.Btn_RemoveData.clicked.connect(self.delete_data)

        # BUTTONS CLICK
        # ///////////////////////////////////////////////////////////////

        # LEFT MENUS
        widgets.Btn_Home.clicked.connect(self.buttonClick)
        widgets.Btn_Search.clicked.connect(self.buttonClick)
        widgets.Btn_Data.clicked.connect(self.buttonClick)
        widgets.Btn_Button.clicked.connect(self.buttonClick)
        widgets.Btn_Setting.clicked.connect(self.buttonClick)

        # SHOW APP
        # ///////////////////////////////////////////////////////////////
        self.show()

        # SET HOME PAGE AND SELECT MENU
        # ///////////////////////////////////////////////////////////////
        widgets.stackedWidget.setCurrentWidget(widgets.page_Home)


    # BUTTONS CLICK
    # Post here your functions for clicked buttons
    # ///////////////////////////////////////////////////////////////
    def buttonClick(self):
        # GET BUTTON CLICKED
        btn = self.sender()
        btnName = btn.objectName()

        # SHOW HOME PAGE
        if btnName == "Btn_Home":
            widgets.stackedWidget.setCurrentWidget(widgets.page_Home)

        if btnName == "Btn_Search":
            widgets.stackedWidget.setCurrentWidget(widgets.page_Search)

        if btnName == "Btn_Data":
            widgets.stackedWidget.setCurrentWidget(widgets.page_Database)


        # PRINT BTN NAME
        print(f'Button "{btnName}" pressed!')

    def open_file(self):

        line_text = widgets.lineEdit_path.text()
        dirName = QFileDialog.getExistingDirectory(self, self.tr("Open Data files"), "./", QFileDialog.ShowDirsOnly)
        if line_text != dirName:
            widgets.lineEdit_path.setText(dirName)
        path = widgets.lineEdit_path.text()
        file_list = os.listdir(path)
        for i in range(len(file_list)):
            print(file_list[i])

    def load_data(self):
        _print = True
        with open('data.pickle', 'rb') as fr:
            user_loaded = pickle.load(fr)
            for i in user_loaded:
                if _print == True:
                    print(f'{i}: {user_loaded[i]}')
            return user_loaded

    def add_data(self, _code:str = '', _artist:str = 'N/A', _title:str = '', _tags:list[str] = []):

        data = self.load_data()
        _code = _code.strip()
        _artist = _artist.strip()
        _title = _title.strip()
        
        data.update({_code:{'artist':_artist,'title':_title,'tags':_tags}})

        with open('data.pickle','wb') as fw:
            pickle.dump(data, fw)

        widgets.lineEdit_Search.setText("")
        self.load_data()

    def delete_data(self):

        data = self.load_data()
        _code = widgets.lineEdit_Search.text().strip()

        if _code != '':

            if _code in data.keys():
                data.pop(_code)
                with open('data.pickle','wb') as fw:
                    pickle.dump(data, fw)
                self.load_data()
            else:
                print(f"[Error] : Code Not Found.")
        else:
            pass

        widgets.lineEdit_Search.setText("")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setWindowIcon(QIcon("icon.ico"))
    window = MainWindow()
    sys.exit(app.exec())
