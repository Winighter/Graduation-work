# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainUWOwHc.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from . resources_rc import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1280, 720)
        MainWindow.setMinimumSize(QSize(1280, 720))
        MainWindow.setStyleSheet(u"")
        self.styleSheet = QWidget(MainWindow)
        self.styleSheet.setObjectName(u"styleSheet")
        self.styleSheet.setMinimumSize(QSize(1280, 720))
        self.styleSheet.setStyleSheet(u"/*QWidget*/\n"
"QWidget {\n"
"background-color: #373737;\n"
"font: 10pt \"Segoe UI\";\n"
"}\n"
"\n"
"/*Top Bar*/\n"
"#frame_PageButton .QPushButton {\n"
"color:#FFFFFF;\n"
"border: none;\n"
"}\n"
"#frame_PageButton .QPushButton:hover{\n"
"background-color: rgb(193, 193, 193);\n"
"}\n"
"#frame_PageButton .QPushButton:pressed{\n"
"	color:#000000;\n"
"	background-color: #FFFFFF;\n"
"}\n"
"#TopBarMenus .QPushButton{\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	border: none;\n"
"}\n"
"#TopBarMenus .QPushButton:hover {\n"
"background-color: rgb(40, 44, 52);\n"
"}\n"
"#TopBarMenus .QPushButton:pressed{\n"
"	background-color: rgb(193, 193, 193);\n"
"}\n"
"/*Top Bar Close Button*/\n"
"#Btn_Close {\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	border: none;\n"
"}\n"
"#Btn_Close:hover {background-color:#ff0000;}\n"
"#Btn_Close:pressed {background-color:#e50000;}\n"
"\n"
"/*Left*/\n"
"#frame_Left .QPushButton:hover{\n"
"	color: #121212;\n"
"	background-color:#FFFFFF"
                        "\n"
"}\n"
"#frame_Left .QPushButton:pressed{\n"
"	color: #121212;\n"
"	background-color: rgb(193, 193, 193);\n"
"}\n"
"\n"
"/*Left Top*/\n"
"#frame_Profile .QLabel{\n"
"color:#ffffff\n"
"}\n"
"#frame_Profile .QFrame{\n"
"background-position: center;\n"
"background-repeat: no-repeat;\n"
"}\n"
"#frame_Profile .QPushButton{\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"}\n"
"\n"
"/*Left Main*/\n"
"#frame_LeftMain .QPushButton{\n"
"background-position:center;\n"
"background-repeat: no-repeat;\n"
"border:none;\n"
"color:#ffffff\n"
"}\n"
"#frame_LeftMain .QPushButton:pressed{\n"
"	background-color: rgb(193, 193, 193);\n"
"}\n"
"#lineEdit_Search {\n"
"border:none;\n"
"color: #FFFFFF;\n"
"border-left: 20px solid transparent;\n"
"text-align: left;\n"
"padding-left: 40px;\n"
"}\n"
"\n"
"#LeftToggleMenus .QPushButton {\n"
"	background-position: left center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"	border-left: 20px solid transparent;\n"
"	text-align: left;\n"
""
                        "	padding-left: 40px;\n"
"	color:#ffffff;\n"
"}\n"
"\n"
"#frame_LeftMenuPages .QPushButton{\n"
"	background-position: left center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"	border-left: 20px solid transparent;\n"
"	text-align: left;\n"
"	padding-left: 40px;\n"
"	color: #FFFFFF;\n"
"}\n"
"\n"
"/*Left Bottom*/\n"
"#frame_LeftBottomMenus .QPushButton{\n"
"	background-position: left center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"	border-left: 20px solid transparent;\n"
"	text-align: left;\n"
"	padding-left: 40px;\n"
"	color: #FFFFFF;\n"
"}\n"
"\n"
"/*Extra Left*/\n"
"#frame_extraLeftSettings .QFrame{\n"
"background-repeat: no-repeat;\n"
"border:none;\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"")
        self.verticalLayout = QVBoxLayout(self.styleSheet)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame_TopBar = QFrame(self.styleSheet)
        self.frame_TopBar.setObjectName(u"frame_TopBar")
        self.frame_TopBar.setMinimumSize(QSize(1280, 30))
        self.frame_TopBar.setStyleSheet(u"")
        self.frame_TopBar.setFrameShape(QFrame.NoFrame)
        self.frame_TopBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_TopBar)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.frame_10 = QFrame(self.frame_TopBar)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setFrameShape(QFrame.NoFrame)
        self.frame_10.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_3.addWidget(self.frame_10)

        self.TopBarMenus = QFrame(self.frame_TopBar)
        self.TopBarMenus.setObjectName(u"TopBarMenus")
        self.TopBarMenus.setMaximumSize(QSize(120, 16777215))
        self.TopBarMenus.setStyleSheet(u"")
        self.TopBarMenus.setFrameShape(QFrame.NoFrame)
        self.TopBarMenus.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.TopBarMenus)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.Btn_SecretMode = QPushButton(self.TopBarMenus)
        self.Btn_SecretMode.setObjectName(u"Btn_SecretMode")
        self.Btn_SecretMode.setMinimumSize(QSize(40, 30))
        self.Btn_SecretMode.setMaximumSize(QSize(40, 30))
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.Btn_SecretMode.setFont(font)
        self.Btn_SecretMode.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-ban.png);")

        self.horizontalLayout_2.addWidget(self.Btn_SecretMode)

        self.Btn_Minimize = QPushButton(self.TopBarMenus)
        self.Btn_Minimize.setObjectName(u"Btn_Minimize")
        self.Btn_Minimize.setMinimumSize(QSize(40, 30))
        self.Btn_Minimize.setMaximumSize(QSize(40, 30))
        self.Btn_Minimize.setFont(font)
        self.Btn_Minimize.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-window-minimize.png);")

        self.horizontalLayout_2.addWidget(self.Btn_Minimize)

        self.Btn_MaximizeRestore = QPushButton(self.TopBarMenus)
        self.Btn_MaximizeRestore.setObjectName(u"Btn_MaximizeRestore")
        self.Btn_MaximizeRestore.setMinimumSize(QSize(40, 30))
        self.Btn_MaximizeRestore.setMaximumSize(QSize(40, 30))
        self.Btn_MaximizeRestore.setFont(font)
        self.Btn_MaximizeRestore.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_maximize.png);")

        self.horizontalLayout_2.addWidget(self.Btn_MaximizeRestore)


        self.horizontalLayout_3.addWidget(self.TopBarMenus)

        self.Btn_Close = QPushButton(self.frame_TopBar)
        self.Btn_Close.setObjectName(u"Btn_Close")
        self.Btn_Close.setMinimumSize(QSize(40, 30))
        self.Btn_Close.setMaximumSize(QSize(40, 30))
        self.Btn_Close.setFont(font)
        self.Btn_Close.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_close.png);\n"
"")

        self.horizontalLayout_3.addWidget(self.Btn_Close)


        self.verticalLayout.addWidget(self.frame_TopBar)

        self.frame = QFrame(self.styleSheet)
        self.frame.setObjectName(u"frame")
        self.frame.setMinimumSize(QSize(1280, 690))
        self.frame.setFrameShape(QFrame.NoFrame)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.frame)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame_Left = QFrame(self.frame)
        self.frame_Left.setObjectName(u"frame_Left")
        self.frame_Left.setMinimumSize(QSize(60, 0))
        self.frame_Left.setMaximumSize(QSize(60, 16777215))
        self.frame_Left.setStyleSheet(u"")
        self.frame_Left.setFrameShape(QFrame.NoFrame)
        self.frame_Left.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame_Left)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.frame_Profile = QFrame(self.frame_Left)
        self.frame_Profile.setObjectName(u"frame_Profile")
        self.frame_Profile.setMinimumSize(QSize(0, 60))
        self.frame_Profile.setMaximumSize(QSize(16777215, 60))
        self.frame_Profile.setStyleSheet(u"QPushButton {\n"
"background-position: center;\n"
"}\n"
"")
        self.frame_Profile.setFrameShape(QFrame.NoFrame)
        self.frame_Profile.setFrameShadow(QFrame.Raised)
        self.frame_ProfileUser = QFrame(self.frame_Profile)
        self.frame_ProfileUser.setObjectName(u"frame_ProfileUser")
        self.frame_ProfileUser.setGeometry(QRect(0, 0, 60, 60))
        self.frame_ProfileUser.setMinimumSize(QSize(0, 0))
        self.frame_ProfileUser.setMaximumSize(QSize(16777215, 16777215))
        self.frame_ProfileUser.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-user.png);")
        self.frame_ProfileUser.setFrameShape(QFrame.NoFrame)
        self.frame_ProfileUser.setFrameShadow(QFrame.Raised)
        self.label_Email = QLabel(self.frame_Profile)
        self.label_Email.setObjectName(u"label_Email")
        self.label_Email.setGeometry(QRect(60, 30, 160, 30))
        self.label_Email.setMinimumSize(QSize(0, 30))
        self.label_Email.setMaximumSize(QSize(160, 16777215))
        self.frame_6 = QFrame(self.frame_Profile)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setGeometry(QRect(61, 1, 161, 30))
        self.frame_6.setMinimumSize(QSize(0, 0))
        self.frame_6.setFrameShape(QFrame.NoFrame)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.Btn_ProfileSetting = QPushButton(self.frame_6)
        self.Btn_ProfileSetting.setObjectName(u"Btn_ProfileSetting")
        self.Btn_ProfileSetting.setGeometry(QRect(130, 0, 30, 30))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Btn_ProfileSetting.sizePolicy().hasHeightForWidth())
        self.Btn_ProfileSetting.setSizePolicy(sizePolicy)
        self.Btn_ProfileSetting.setMinimumSize(QSize(0, 0))
        self.Btn_ProfileSetting.setMaximumSize(QSize(30, 30))
        self.Btn_ProfileSetting.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-options.png);")
        self.label_Name = QLabel(self.frame_6)
        self.label_Name.setObjectName(u"label_Name")
        self.label_Name.setGeometry(QRect(0, 0, 130, 30))
        self.label_Name.setMaximumSize(QSize(160, 16777215))
        self.label_Name.setFont(font)

        self.verticalLayout_2.addWidget(self.frame_Profile)

        self.frame_LeftMain = QFrame(self.frame_Left)
        self.frame_LeftMain.setObjectName(u"frame_LeftMain")
        self.frame_LeftMain.setFrameShape(QFrame.NoFrame)
        self.frame_LeftMain.setFrameShadow(QFrame.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.frame_LeftMain)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.LeftTabMenus = QFrame(self.frame_LeftMain)
        self.LeftTabMenus.setObjectName(u"LeftTabMenus")
        self.LeftTabMenus.setMinimumSize(QSize(220, 30))
        self.LeftTabMenus.setMaximumSize(QSize(16777215, 16777215))
        self.LeftTabMenus.setFrameShape(QFrame.NoFrame)
        self.LeftTabMenus.setFrameShadow(QFrame.Raised)

        self.verticalLayout_12.addWidget(self.LeftTabMenus)

        self.frame_LeftMenuPages = QFrame(self.frame_LeftMain)
        self.frame_LeftMenuPages.setObjectName(u"frame_LeftMenuPages")
        self.frame_LeftMenuPages.setStyleSheet(u"")
        self.frame_LeftMenuPages.setFrameShape(QFrame.NoFrame)
        self.frame_LeftMenuPages.setFrameShadow(QFrame.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_LeftMenuPages)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget_Left = QStackedWidget(self.frame_LeftMenuPages)
        self.stackedWidget_Left.setObjectName(u"stackedWidget_Left")
        self.stackedWidget_Left.setStyleSheet(u"")
        self.page_LeftMenu_2 = QWidget()
        self.page_LeftMenu_2.setObjectName(u"page_LeftMenu_2")
        self.verticalLayout_6 = QVBoxLayout(self.page_LeftMenu_2)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.frame_8 = QFrame(self.page_LeftMenu_2)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setFrameShape(QFrame.NoFrame)
        self.frame_8.setFrameShadow(QFrame.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.frame_8)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.Btn_sHome = QPushButton(self.frame_8)
        self.Btn_sHome.setObjectName(u"Btn_sHome")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.Btn_sHome.sizePolicy().hasHeightForWidth())
        self.Btn_sHome.setSizePolicy(sizePolicy1)
        self.Btn_sHome.setMinimumSize(QSize(0, 40))
        self.Btn_sHome.setMaximumSize(QSize(16777215, 16777215))
        self.Btn_sHome.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-home.png);")

        self.verticalLayout_14.addWidget(self.Btn_sHome)

        self.Btn_sPage_2 = QPushButton(self.frame_8)
        self.Btn_sPage_2.setObjectName(u"Btn_sPage_2")
        sizePolicy1.setHeightForWidth(self.Btn_sPage_2.sizePolicy().hasHeightForWidth())
        self.Btn_sPage_2.setSizePolicy(sizePolicy1)
        self.Btn_sPage_2.setMinimumSize(QSize(0, 40))
        self.Btn_sPage_2.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-browser.png);")

        self.verticalLayout_14.addWidget(self.Btn_sPage_2)

        self.Btn_sPage_3 = QPushButton(self.frame_8)
        self.Btn_sPage_3.setObjectName(u"Btn_sPage_3")
        sizePolicy1.setHeightForWidth(self.Btn_sPage_3.sizePolicy().hasHeightForWidth())
        self.Btn_sPage_3.setSizePolicy(sizePolicy1)
        self.Btn_sPage_3.setMinimumSize(QSize(0, 40))
        self.Btn_sPage_3.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-browser.png);")

        self.verticalLayout_14.addWidget(self.Btn_sPage_3)

        self.Btn_sPage_4 = QPushButton(self.frame_8)
        self.Btn_sPage_4.setObjectName(u"Btn_sPage_4")
        sizePolicy1.setHeightForWidth(self.Btn_sPage_4.sizePolicy().hasHeightForWidth())
        self.Btn_sPage_4.setSizePolicy(sizePolicy1)
        self.Btn_sPage_4.setMinimumSize(QSize(0, 40))
        self.Btn_sPage_4.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-browser.png);")

        self.verticalLayout_14.addWidget(self.Btn_sPage_4)

        self.Btn_sPage_5 = QPushButton(self.frame_8)
        self.Btn_sPage_5.setObjectName(u"Btn_sPage_5")
        sizePolicy1.setHeightForWidth(self.Btn_sPage_5.sizePolicy().hasHeightForWidth())
        self.Btn_sPage_5.setSizePolicy(sizePolicy1)
        self.Btn_sPage_5.setMinimumSize(QSize(0, 40))
        self.Btn_sPage_5.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-browser.png);")

        self.verticalLayout_14.addWidget(self.Btn_sPage_5)


        self.verticalLayout_6.addWidget(self.frame_8, 0, Qt.AlignTop)

        self.stackedWidget_Left.addWidget(self.page_LeftMenu_2)
        self.page_LeftMenu_1 = QWidget()
        self.page_LeftMenu_1.setObjectName(u"page_LeftMenu_1")
        self.verticalLayout_3 = QVBoxLayout(self.page_LeftMenu_1)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.LeftMainMenus = QFrame(self.page_LeftMenu_1)
        self.LeftMainMenus.setObjectName(u"LeftMainMenus")
        self.LeftMainMenus.setFrameShape(QFrame.NoFrame)
        self.LeftMainMenus.setFrameShadow(QFrame.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.LeftMainMenus)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.Btn_Home = QPushButton(self.LeftMainMenus)
        self.Btn_Home.setObjectName(u"Btn_Home")
        sizePolicy1.setHeightForWidth(self.Btn_Home.sizePolicy().hasHeightForWidth())
        self.Btn_Home.setSizePolicy(sizePolicy1)
        self.Btn_Home.setMinimumSize(QSize(0, 40))
        self.Btn_Home.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-home.png);")

        self.verticalLayout_4.addWidget(self.Btn_Home)

        self.Btn_myTasks = QPushButton(self.LeftMainMenus)
        self.Btn_myTasks.setObjectName(u"Btn_myTasks")
        sizePolicy1.setHeightForWidth(self.Btn_myTasks.sizePolicy().hasHeightForWidth())
        self.Btn_myTasks.setSizePolicy(sizePolicy1)
        self.Btn_myTasks.setMinimumSize(QSize(0, 40))
        self.Btn_myTasks.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-task.png);")

        self.verticalLayout_4.addWidget(self.Btn_myTasks)

        self.pushButton_4 = QPushButton(self.LeftMainMenus)
        self.pushButton_4.setObjectName(u"pushButton_4")
        sizePolicy1.setHeightForWidth(self.pushButton_4.sizePolicy().hasHeightForWidth())
        self.pushButton_4.setSizePolicy(sizePolicy1)
        self.pushButton_4.setMinimumSize(QSize(0, 40))
        self.pushButton_4.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-ban.png);")

        self.verticalLayout_4.addWidget(self.pushButton_4)

        self.pushButton_5 = QPushButton(self.LeftMainMenus)
        self.pushButton_5.setObjectName(u"pushButton_5")
        sizePolicy1.setHeightForWidth(self.pushButton_5.sizePolicy().hasHeightForWidth())
        self.pushButton_5.setSizePolicy(sizePolicy1)
        self.pushButton_5.setMinimumSize(QSize(0, 40))
        self.pushButton_5.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-ban.png);")

        self.verticalLayout_4.addWidget(self.pushButton_5)

        self.Btn_Developer = QPushButton(self.LeftMainMenus)
        self.Btn_Developer.setObjectName(u"Btn_Developer")
        sizePolicy1.setHeightForWidth(self.Btn_Developer.sizePolicy().hasHeightForWidth())
        self.Btn_Developer.setSizePolicy(sizePolicy1)
        self.Btn_Developer.setMinimumSize(QSize(0, 40))
        self.Btn_Developer.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-terminal.png);")

        self.verticalLayout_4.addWidget(self.Btn_Developer)


        self.verticalLayout_3.addWidget(self.LeftMainMenus, 0, Qt.AlignTop)

        self.stackedWidget_Left.addWidget(self.page_LeftMenu_1)

        self.verticalLayout_5.addWidget(self.stackedWidget_Left)


        self.verticalLayout_12.addWidget(self.frame_LeftMenuPages)


        self.verticalLayout_2.addWidget(self.frame_LeftMain)

        self.frame_LeftBottomMenus = QFrame(self.frame_Left)
        self.frame_LeftBottomMenus.setObjectName(u"frame_LeftBottomMenus")
        self.frame_LeftBottomMenus.setMinimumSize(QSize(0, 0))
        self.frame_LeftBottomMenus.setMaximumSize(QSize(16777215, 16777215))
        self.frame_LeftBottomMenus.setStyleSheet(u"")
        self.frame_LeftBottomMenus.setFrameShape(QFrame.NoFrame)
        self.frame_LeftBottomMenus.setFrameShadow(QFrame.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_LeftBottomMenus)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.Btn_Notifications = QPushButton(self.frame_LeftBottomMenus)
        self.Btn_Notifications.setObjectName(u"Btn_Notifications")
        sizePolicy1.setHeightForWidth(self.Btn_Notifications.sizePolicy().hasHeightForWidth())
        self.Btn_Notifications.setSizePolicy(sizePolicy1)
        self.Btn_Notifications.setMinimumSize(QSize(0, 40))
        self.Btn_Notifications.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-bell.png);")

        self.verticalLayout_7.addWidget(self.Btn_Notifications)

        self.Btn_Support = QPushButton(self.frame_LeftBottomMenus)
        self.Btn_Support.setObjectName(u"Btn_Support")
        sizePolicy1.setHeightForWidth(self.Btn_Support.sizePolicy().hasHeightForWidth())
        self.Btn_Support.setSizePolicy(sizePolicy1)
        self.Btn_Support.setMinimumSize(QSize(0, 40))
        self.Btn_Support.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-headphones.png);")

        self.verticalLayout_7.addWidget(self.Btn_Support)

        self.Btn_Settings = QPushButton(self.frame_LeftBottomMenus)
        self.Btn_Settings.setObjectName(u"Btn_Settings")
        sizePolicy1.setHeightForWidth(self.Btn_Settings.sizePolicy().hasHeightForWidth())
        self.Btn_Settings.setSizePolicy(sizePolicy1)
        self.Btn_Settings.setMinimumSize(QSize(0, 40))
        self.Btn_Settings.setLayoutDirection(Qt.LeftToRight)
        self.Btn_Settings.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-settings.png);\n"
"")

        self.verticalLayout_7.addWidget(self.Btn_Settings)


        self.verticalLayout_2.addWidget(self.frame_LeftBottomMenus)


        self.horizontalLayout.addWidget(self.frame_Left)

        self.frame_Main = QFrame(self.frame)
        self.frame_Main.setObjectName(u"frame_Main")
        self.frame_Main.setStyleSheet(u"background:transparent;")
        self.frame_Main.setFrameShape(QFrame.NoFrame)
        self.frame_Main.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.frame_Main)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.frame_Content = QFrame(self.frame_Main)
        self.frame_Content.setObjectName(u"frame_Content")
        self.frame_Content.setMinimumSize(QSize(1220, 0))
        self.frame_Content.setFrameShape(QFrame.NoFrame)
        self.frame_Content.setFrameShadow(QFrame.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.frame_Content)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget_Main = QStackedWidget(self.frame_Content)
        self.stackedWidget_Main.setObjectName(u"stackedWidget_Main")
        self.stackedWidget_Main.setMinimumSize(QSize(1220, 690))
        self.stackedWidget_Main.setMaximumSize(QSize(16777215, 16777215))
        self.page_Home = QWidget()
        self.page_Home.setObjectName(u"page_Home")
        self.page_Home.setStyleSheet(u"")
        self.verticalLayout_10 = QVBoxLayout(self.page_Home)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.Home = QFrame(self.page_Home)
        self.Home.setObjectName(u"Home")
        self.Home.setStyleSheet(u"")
        self.Home.setFrameShape(QFrame.NoFrame)
        self.Home.setFrameShadow(QFrame.Raised)

        self.verticalLayout_10.addWidget(self.Home)

        self.stackedWidget_Main.addWidget(self.page_Home)
        self.page_2 = QWidget()
        self.page_2.setObjectName(u"page_2")
        self.verticalLayout_17 = QVBoxLayout(self.page_2)
        self.verticalLayout_17.setSpacing(0)
        self.verticalLayout_17.setObjectName(u"verticalLayout_17")
        self.verticalLayout_17.setContentsMargins(0, 0, 0, 0)
        self.Page_2 = QFrame(self.page_2)
        self.Page_2.setObjectName(u"Page_2")
        self.Page_2.setFrameShape(QFrame.StyledPanel)
        self.Page_2.setFrameShadow(QFrame.Raised)

        self.verticalLayout_17.addWidget(self.Page_2)

        self.stackedWidget_Main.addWidget(self.page_2)
        self.page_3 = QWidget()
        self.page_3.setObjectName(u"page_3")
        self.verticalLayout_18 = QVBoxLayout(self.page_3)
        self.verticalLayout_18.setSpacing(0)
        self.verticalLayout_18.setObjectName(u"verticalLayout_18")
        self.verticalLayout_18.setContentsMargins(0, 0, 0, 0)
        self.Page_3 = QFrame(self.page_3)
        self.Page_3.setObjectName(u"Page_3")
        self.Page_3.setFrameShape(QFrame.StyledPanel)
        self.Page_3.setFrameShadow(QFrame.Raised)

        self.verticalLayout_18.addWidget(self.Page_3)

        self.stackedWidget_Main.addWidget(self.page_3)
        self.page_4 = QWidget()
        self.page_4.setObjectName(u"page_4")
        self.verticalLayout_20 = QVBoxLayout(self.page_4)
        self.verticalLayout_20.setSpacing(0)
        self.verticalLayout_20.setObjectName(u"verticalLayout_20")
        self.verticalLayout_20.setContentsMargins(0, 0, 0, 0)
        self.Page_4 = QFrame(self.page_4)
        self.Page_4.setObjectName(u"Page_4")
        self.Page_4.setFrameShape(QFrame.StyledPanel)
        self.Page_4.setFrameShadow(QFrame.Raised)

        self.verticalLayout_20.addWidget(self.Page_4)

        self.stackedWidget_Main.addWidget(self.page_4)
        self.page_5 = QWidget()
        self.page_5.setObjectName(u"page_5")
        self.verticalLayout_19 = QVBoxLayout(self.page_5)
        self.verticalLayout_19.setSpacing(0)
        self.verticalLayout_19.setObjectName(u"verticalLayout_19")
        self.verticalLayout_19.setContentsMargins(0, 0, 0, 0)
        self.Page_5 = QFrame(self.page_5)
        self.Page_5.setObjectName(u"Page_5")
        self.Page_5.setFrameShape(QFrame.StyledPanel)
        self.Page_5.setFrameShadow(QFrame.Raised)

        self.verticalLayout_19.addWidget(self.Page_5)

        self.stackedWidget_Main.addWidget(self.page_5)
        self.page_sPage_2 = QWidget()
        self.page_sPage_2.setObjectName(u"page_sPage_2")
        self.page_sPage_2.setStyleSheet(u"background-image: url(:/images/images/images/000.jpg);\n"
"background-position: center;\n"
"background-repeat: no-repeat;")
        self.verticalLayout_11 = QVBoxLayout(self.page_sPage_2)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.sPage_2 = QFrame(self.page_sPage_2)
        self.sPage_2.setObjectName(u"sPage_2")
        self.sPage_2.setStyleSheet(u"")
        self.sPage_2.setFrameShape(QFrame.NoFrame)
        self.sPage_2.setFrameShadow(QFrame.Raised)

        self.verticalLayout_11.addWidget(self.sPage_2)

        self.stackedWidget_Main.addWidget(self.page_sPage_2)
        self.page_sPage_3 = QWidget()
        self.page_sPage_3.setObjectName(u"page_sPage_3")
        self.page_sPage_3.setStyleSheet(u"background-image: url(:/images/images/images/001.jpg);\n"
"background-position: center;\n"
"background-repeat: no-repeat;")
        self.verticalLayout_8 = QVBoxLayout(self.page_sPage_3)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.sPage_3 = QFrame(self.page_sPage_3)
        self.sPage_3.setObjectName(u"sPage_3")
        self.sPage_3.setFrameShape(QFrame.NoFrame)
        self.sPage_3.setFrameShadow(QFrame.Raised)

        self.verticalLayout_8.addWidget(self.sPage_3)

        self.stackedWidget_Main.addWidget(self.page_sPage_3)
        self.page_sPage_4 = QWidget()
        self.page_sPage_4.setObjectName(u"page_sPage_4")
        self.verticalLayout_13 = QVBoxLayout(self.page_sPage_4)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.sPage_4 = QFrame(self.page_sPage_4)
        self.sPage_4.setObjectName(u"sPage_4")
        self.sPage_4.setFrameShape(QFrame.NoFrame)
        self.sPage_4.setFrameShadow(QFrame.Raised)

        self.verticalLayout_13.addWidget(self.sPage_4)

        self.stackedWidget_Main.addWidget(self.page_sPage_4)
        self.page_sPage_5 = QWidget()
        self.page_sPage_5.setObjectName(u"page_sPage_5")
        self.verticalLayout_16 = QVBoxLayout(self.page_sPage_5)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(0, 0, 0, 0)
        self.sPage_5 = QFrame(self.page_sPage_5)
        self.sPage_5.setObjectName(u"sPage_5")
        self.sPage_5.setFrameShape(QFrame.StyledPanel)
        self.sPage_5.setFrameShadow(QFrame.Raised)

        self.verticalLayout_16.addWidget(self.sPage_5)

        self.stackedWidget_Main.addWidget(self.page_sPage_5)
        self.page_sHome = QWidget()
        self.page_sHome.setObjectName(u"page_sHome")
        self.verticalLayout_15 = QVBoxLayout(self.page_sHome)
        self.verticalLayout_15.setSpacing(0)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(0, 0, 0, 0)
        self.sHome = QFrame(self.page_sHome)
        self.sHome.setObjectName(u"sHome")
        self.sHome.setFrameShape(QFrame.NoFrame)
        self.sHome.setFrameShadow(QFrame.Raised)

        self.verticalLayout_15.addWidget(self.sHome)

        self.stackedWidget_Main.addWidget(self.page_sHome)

        self.verticalLayout_9.addWidget(self.stackedWidget_Main)


        self.horizontalLayout_4.addWidget(self.frame_Content)


        self.horizontalLayout.addWidget(self.frame_Main)


        self.verticalLayout.addWidget(self.frame)

        MainWindow.setCentralWidget(self.styleSheet)

        self.retranslateUi(MainWindow)

        self.stackedWidget_Left.setCurrentIndex(1)
        self.stackedWidget_Main.setCurrentIndex(4)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.Btn_SecretMode.setText("")
        self.Btn_Minimize.setText("")
        self.Btn_MaximizeRestore.setText("")
        self.Btn_Close.setText("")
        self.label_Email.setText(QCoreApplication.translate("MainWindow", u"abc1234@email.com", None))
        self.Btn_ProfileSetting.setText("")
        self.label_Name.setText(QCoreApplication.translate("MainWindow", u"Who Who", None))
        self.Btn_sHome.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.Btn_sPage_2.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_sPage_3.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_sPage_4.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_sPage_5.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_Home.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.Btn_myTasks.setText(QCoreApplication.translate("MainWindow", u"My Tasks", None))
        self.pushButton_4.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.pushButton_5.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_Developer.setText(QCoreApplication.translate("MainWindow", u"Developer Options", None))
        self.Btn_Notifications.setText(QCoreApplication.translate("MainWindow", u"Notifications", None))
        self.Btn_Support.setText(QCoreApplication.translate("MainWindow", u"Support", None))
        self.Btn_Settings.setText(QCoreApplication.translate("MainWindow", u"Settings", None))
    # retranslateUi

