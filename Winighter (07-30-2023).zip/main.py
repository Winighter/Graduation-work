import sys
from PySide2.QtWidgets import QMainWindow

from modules import *

widgets = None
counter = 1
TAB = False
class LoginScreen(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.login_ui = Ui_LoginScreen()
        self.login_ui.setupUi(self)
        Ui_Functions.uiLoginDefinitions(self)

        self.login_ui.Btn_Login.clicked.connect(self.onLogin)
        self.login_ui.Btn_Approve.clicked.connect(self.onLogin)
        self.login_ui.Btn_Deny.clicked.connect(self.onLogin)

        self.show()
        self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)

    def onLogin(self):
        # GET BUTTON CLICKED
        btn = self.sender()
        btnName = btn.objectName()
        if btnName == "Btn_Login":
            id = self.login_ui.LineEdit_ID.text()
            pw = self.login_ui.LineEdit_PW.text()

            if id == '' and pw == '':

                self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_otp)
                self.timer = QTimer()
                self.timer.timeout.connect(self.update)
                self.timer.start(1000)
            else:
                AppFunctions.loginScreenState(self)

        if btnName == "Btn_Approve":
            self.timer.stop()
            self.close()
            MainWindow()
            
        if btnName == "Btn_Deny":
            self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)

    def update(self):
        global counter
        self.login_ui.label_totp_remaining_time.setText("%ss"%(10-counter))
        if counter >= 10:
            counter = 0
            self.login_ui.label_totp_remaining_time.setText("10s")
            self.login_ui.label_TOTP.setText(SecurityManager.get_otpCode(self))
        counter += 1
 

    def mousePressEvent(self, event):
        # SET DRAG POS WINDOW
        self.dragPos = event.globalPos()

class MainWindow(QMainWindow,QWidget):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        global widgets
        widgets = self.ui

        Ui_Functions.uiDefaultSet(self)
        # widgets.frame_Main.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        # Top Buttons

        # Left Secret Page Button
        widgets.Btn_sHome.clicked.connect(self.onClick)
        widgets.Btn_sPage_2.clicked.connect(self.onClick)
        widgets.Btn_sPage_3.clicked.connect(self.onClick)
        widgets.Btn_sPage_4.clicked.connect(self.onClick)

        # Left Button
        widgets.Btn_SecretMode.clicked.connect(lambda: Ui_Functions.toggleLeftMenuTab(self))
        widgets.Btn_Home.clicked.connect(self.onClick)

        # Left Toggle Button
        widgets.Btn_Settings.clicked.connect(lambda: Ui_Functions.toggleFrameLeft(self, True))

        self.show()

    def onClick(self):
        btn = self.sender()
        btnName = btn.objectName()
        # Left Page Button
        if btnName == 'Btn_Home':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_Home)

        # if btnName == 'Btn_sPage_2':
        #     widgets.stackedWidget_Main.setCurrentWidget(widgets.Page_2)

        # if btnName == 'Btn_sPage_3':
        #     widgets.stackedWidget_Main.setCurrentWidget(widgets.Page_3)

        # if btnName == 'Btn_sPage_4':
        #     widgets.stackedWidget_Main.setCurrentWidget(widgets.Page_4)

        # if btnName == 'Btn_sPage_5':
        #     widgets.stackedWidget_Main.setCurrentWidget(widgets.Page_5)

        # Left Secret Page Button
        if btnName == 'Btn_sHome':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sHome)

        if btnName == 'Btn_sPage_2':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_2)

        if btnName == 'Btn_sPage_3':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_3)

        if btnName == 'Btn_sPage_4':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_4)

        if btnName == 'Btn_sPage_5':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_sPage_5)

    def mouseMoveEvent(self, event):
        print(event.x(),event.y())

if __name__ == "__main__":
    app = QApplication(sys.argv)
    login = LoginScreen()
    sys.exit(app.exec_())

# pyside2-rcc resources.qrc -o resources_rc.py

# from . resources_rc import *