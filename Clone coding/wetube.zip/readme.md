# Wetube Reloaded

Visit your newly deployed app at https://wetubes.fly.dev/

/ -> Home
/search?s=SearchText -> Search
/watch?v=VideoCodes -> No login can watch
/ ->
/ ->
/ ->
/ ->
