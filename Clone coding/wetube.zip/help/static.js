// How to make static?
//videoSchema.static("staticeName(Custom)", function (argument) {return ~~~})
