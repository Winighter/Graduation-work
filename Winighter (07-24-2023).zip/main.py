import sys
from PySide2.QtWidgets import QMainWindow

from modules import *
from security import *
widgets = None
counter = 1

class LoginScreen(QMainWindow):
    def __init__(self):
        QMainWindow.__init__(self)
        self.login_ui = Ui_LoginScreen()
        self.login_ui.setupUi(self)
        Ui_Functions.uiLoginDefinitions(self)
        self.login_ui.Btn_Login.clicked.connect(self.onLogin)
        self.login_ui.Btn_Approve.clicked.connect(self.onLogin)
        self.login_ui.Btn_Deny.clicked.connect(self.onLogin)
        self.show()
        self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)

    def onLogin(self):
        # GET BUTTON CLICKED
        btn = self.sender()
        btnName = btn.objectName()
        if btnName == "Btn_Login":
            id = self.login_ui.LineEdit_ID.text()
            pw = self.login_ui.LineEdit_PW.text()

            if id == '' and pw == '':

                self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_otp)
                self.otp_code = SecurityManager.get_otpCode(self)
                self.login_ui.label_TOTP.setText(self.otp_code)

                self.timer = QTimer()
                self.timer.timeout.connect(self.update)
                self.timer.start(1000)
            else:
                AppFunctions.loginScreenState(self)

        if btnName == "Btn_Approve":
            self.timer.stop()
            self.close()
            MainWindow()
            SecurityManager()
            
        if btnName == "Btn_Deny":
            self.login_ui.stackedWidget.setCurrentWidget(self.login_ui.page_login)

    def update(self):
        global counter
        self.login_ui.label_totp_remaining_time.setText("%ss"%(10-counter))
        if counter >= 10:
            counter = 0
            self.login_ui.label_totp_remaining_time.setText("10s")
            self.login_ui.label_TOTP.setText(SecurityManager.get_otpCode(self))
        counter += 1
 

    def mousePressEvent(self, event):
        # SET DRAG POS WINDOW
        self.dragPos = event.globalPos()

class MainWindow(QMainWindow,QWidget):
    def __init__(self):
        QMainWindow.__init__(self)
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        global widgets
        widgets = self.ui

        Ui_Functions.uiDefaultSet(self)

        # Left Button
        widgets.Btn_LeftMenuTab_1.clicked.connect(self.onClick)
        widgets.Btn_LeftMenuTab_2.clicked.connect(self.onClick)
        widgets.Btn_Home.clicked.connect(self.onClick)

        # Left Toggle Button
        widgets.Btn_Settings.clicked.connect(lambda: Ui_Functions.toggleExtraLeft(self, True))
        
        self.show()

    def onClick(self):
        btn = self.sender()
        btnName = btn.objectName()

        if btnName == 'Btn_LeftMenuTab_1': 
            widgets.stackedWidget_Left.setCurrentWidget(widgets.page_LeftMenu_1)

        if btnName == 'Btn_LeftMenuTab_2':
            widgets.stackedWidget_Left.setCurrentWidget(widgets.page_LeftMenu_2)
            
        if btnName == 'Btn_Home':
            widgets.stackedWidget_Main.setCurrentWidget(widgets.page_Home)
    
        print(btnName)
        
    # Left Toggle Funtions
    def enterEvent(self, event):
        Ui_Functions.toggleMenu(self, True, 220)

    def leaveEvent(self, event):
        Ui_Functions.toggleMenu(self, True, 60)

    def mouseMoveEvent(self, event):
        print(event.x(),event.y())

        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    login = LoginScreen()
    sys.exit(app.exec_())

# pyside2-rcc resources.qrc -o resources_rc.py

# from . resources_rc import *