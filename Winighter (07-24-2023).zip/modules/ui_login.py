# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'loginsVweIw.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_LoginScreen(object):
    def setupUi(self, LoginScreen):
        if not LoginScreen.objectName():
            LoginScreen.setObjectName(u"LoginScreen")
        LoginScreen.resize(270, 380)
        LoginScreen.setMinimumSize(QSize(270, 380))
        LoginScreen.setMaximumSize(QSize(350, 380))
        self.bgApp = QWidget(LoginScreen)
        self.bgApp.setObjectName(u"bgApp")
        self.bgApp.setMinimumSize(QSize(270, 380))
        self.bgApp.setMaximumSize(QSize(270, 380))
        self.bgApp.setStyleSheet(u"/*QWidget*/\n"
"QWidget {\n"
"color:#FFFFFF;\n"
"background-color: #121212;\n"
"}\n"
"/*Top Bar//////////////////////////////////////////////////////*/\n"
"/*Left Top Bar*/\n"
"#label_description{color: #FFFFFF;}\n"
"\n"
"/*Rigth Top Bar*/\n"
"#RightTopBar .QPushButton{color: #FFFFFF;border: none;}\n"
"#RightTopBar .QPushButton:hover {background-color:#FFB471;}\n"
"#RightTopBar .QPushButton:pressed{background-color: #ADBED2;}\n"
"\n"
"/*Main////////////////////////////////////////////////////////*/\n"
"/*Login Page*/\n"
"#label_LoginState{color: #E81E25;}\n"
"#label_Login {color:#FFFFFF;}\n"
"#frame .QLineEdit{color:#FFFFFF;}\n"
"#frame_6 .QPushButton{color:#FFFFFF;}\n"
"#Btn_Login {\n"
"color:#FFFFFF;\n"
"background-color: #FFB471;\n"
"border: 0px solid;\n"
"border-radius:20px;\n"
"}\n"
"#Btn_Login .QPushButton:hover {background-color: #DBDBE5}\n"
"\n"
"/*Page Otp*/\n"
"#frame_5 {background-color:#FFFFFF;border-radius:105px}\n"
"#frame_5 .QLabel{color:#000000;}\n"
"\n"
"/*Bottom Bar///////////////////////////"
                        "/////////////*/\n"
"/*Left Bottom*/\n"
"#LoginStateLabel {padding-left:5px;}\n"
"/*Right Bottom*/\n"
"#label_version{color:#FFFFFF;padding-right:5px;}\n"
"\n"
"\n"
"")
        self.verticalLayout = QVBoxLayout(self.bgApp)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.TopBar = QFrame(self.bgApp)
        self.TopBar.setObjectName(u"TopBar")
        self.TopBar.setMinimumSize(QSize(0, 30))
        self.TopBar.setMaximumSize(QSize(16777215, 30))
        self.TopBar.setFrameShape(QFrame.NoFrame)
        self.TopBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.TopBar)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame_2 = QFrame(self.TopBar)
        self.frame_2.setObjectName(u"frame_2")
        font = QFont()
        font.setPointSize(9)
        font.setBold(False)
        font.setWeight(50)
        self.frame_2.setFont(font)
        self.frame_2.setStyleSheet(u"")
        self.frame_2.setFrameShape(QFrame.NoFrame)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_2)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(10, 0, 0, 0)
        self.label_2 = QLabel(self.frame_2)
        self.label_2.setObjectName(u"label_2")
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setWeight(75)
        self.label_2.setFont(font1)

        self.verticalLayout_7.addWidget(self.label_2)


        self.horizontalLayout.addWidget(self.frame_2)

        self.frame_3 = QFrame(self.TopBar)
        self.frame_3.setObjectName(u"frame_3")
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.frame_3.sizePolicy().hasHeightForWidth())
        self.frame_3.setSizePolicy(sizePolicy)
        self.frame_3.setMaximumSize(QSize(80, 16777215))
        self.frame_3.setStyleSheet(u"QPushButton {color: rgb(255, 255, 255);background-color: #0E0301;border: 0px solid}\n"
"QPushButton:hover {background-color: #3C4048}")
        self.frame_3.setFrameShape(QFrame.NoFrame)
        self.frame_3.setFrameShadow(QFrame.Raised)
        self.frame_3.setLineWidth(1)
        self.horizontalLayout_2 = QHBoxLayout(self.frame_3)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.Btn_Minimize = QPushButton(self.frame_3)
        self.Btn_Minimize.setObjectName(u"Btn_Minimize")
        sizePolicy.setHeightForWidth(self.Btn_Minimize.sizePolicy().hasHeightForWidth())
        self.Btn_Minimize.setSizePolicy(sizePolicy)
        self.Btn_Minimize.setMinimumSize(QSize(40, 0))
        self.Btn_Minimize.setStyleSheet(u"QPushButton {color:#000000;background-color: #FFFFFF;border: 0px solid}\n"
"QPushButton:hover {background-color: #DBDBE5}")

        self.horizontalLayout_2.addWidget(self.Btn_Minimize)

        self.Btn_Close = QPushButton(self.frame_3)
        self.Btn_Close.setObjectName(u"Btn_Close")
        sizePolicy.setHeightForWidth(self.Btn_Close.sizePolicy().hasHeightForWidth())
        self.Btn_Close.setSizePolicy(sizePolicy)
        self.Btn_Close.setMinimumSize(QSize(40, 0))
        self.Btn_Close.setStyleSheet(u"QPushButton {color:#000000;background-color: #FFFFFF;border: 0px solid}\n"
"QPushButton:hover {background-color: #E81E25}")

        self.horizontalLayout_2.addWidget(self.Btn_Close)


        self.horizontalLayout.addWidget(self.frame_3)


        self.verticalLayout.addWidget(self.TopBar)

        self.stackedWidget = QStackedWidget(self.bgApp)
        self.stackedWidget.setObjectName(u"stackedWidget")
        self.page_login = QWidget()
        self.page_login.setObjectName(u"page_login")
        self.verticalLayout_3 = QVBoxLayout(self.page_login)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.frame = QFrame(self.page_login)
        self.frame.setObjectName(u"frame")
        sizePolicy1 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Preferred)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.frame.sizePolicy().hasHeightForWidth())
        self.frame.setSizePolicy(sizePolicy1)
        self.frame.setStyleSheet(u"")
        self.frame.setInputMethodHints(Qt.ImhHiddenText)
        self.frame.setFrameShape(QFrame.NoFrame)
        self.frame.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame)
        self.verticalLayout_2.setSpacing(10)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(30, 30, 30, 0)
        self.label_login_state = QLabel(self.frame)
        self.label_login_state.setObjectName(u"label_login_state")
        self.label_login_state.setMaximumSize(QSize(16777215, 25))
        font2 = QFont()
        font2.setPointSize(10)
        font2.setBold(False)
        font2.setWeight(50)
        self.label_login_state.setFont(font2)
        self.label_login_state.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.label_login_state)

        self.label = QLabel(self.frame)
        self.label.setObjectName(u"label")
        self.label.setMaximumSize(QSize(16777215, 50))
        font3 = QFont()
        font3.setPointSize(30)
        self.label.setFont(font3)
        self.label.setAlignment(Qt.AlignCenter)

        self.verticalLayout_2.addWidget(self.label)

        self.LineEdit_ID = QLineEdit(self.frame)
        self.LineEdit_ID.setObjectName(u"LineEdit_ID")
        sizePolicy2 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy2.setHorizontalStretch(0)
        sizePolicy2.setVerticalStretch(0)
        sizePolicy2.setHeightForWidth(self.LineEdit_ID.sizePolicy().hasHeightForWidth())
        self.LineEdit_ID.setSizePolicy(sizePolicy2)
        self.LineEdit_ID.setMinimumSize(QSize(0, 25))
        self.LineEdit_ID.setStyleSheet(u"background-color:rgba(0, 0, 0, 0);\n"
"border:none;\n"
"border-bottom:2px solid #FFFFFF;\n"
"padding-bottom:7px;")
        self.LineEdit_ID.setInputMethodHints(Qt.ImhNone)

        self.verticalLayout_2.addWidget(self.LineEdit_ID)

        self.LineEdit_PW = QLineEdit(self.frame)
        self.LineEdit_PW.setObjectName(u"LineEdit_PW")
        self.LineEdit_PW.setMinimumSize(QSize(0, 25))
        self.LineEdit_PW.setStyleSheet(u"background-color:rgba(0, 0, 0, 0);\n"
"border:none;\n"
"border-bottom:2px solid #FFFFFF;\n"
"padding-bottom:7px;")
        self.LineEdit_PW.setInputMethodHints(Qt.ImhHiddenText|Qt.ImhNoAutoUppercase|Qt.ImhNoPredictiveText|Qt.ImhSensitiveData)
        self.LineEdit_PW.setEchoMode(QLineEdit.Password)

        self.verticalLayout_2.addWidget(self.LineEdit_PW)

        self.Btn_Login = QPushButton(self.frame)
        self.Btn_Login.setObjectName(u"Btn_Login")
        self.Btn_Login.setEnabled(True)
        sizePolicy3 = QSizePolicy(QSizePolicy.Preferred, QSizePolicy.Fixed)
        sizePolicy3.setHorizontalStretch(0)
        sizePolicy3.setVerticalStretch(0)
        sizePolicy3.setHeightForWidth(self.Btn_Login.sizePolicy().hasHeightForWidth())
        self.Btn_Login.setSizePolicy(sizePolicy3)
        self.Btn_Login.setMinimumSize(QSize(0, 40))
        self.Btn_Login.setFont(font1)
        self.Btn_Login.setStyleSheet(u"QPushButton {color:#000000;background-color: #FFFFFF;border: 0px solid;border-radius:20px}\n"
"QPushButton:hover {background-color: #DBDBE5}")

        self.verticalLayout_2.addWidget(self.Btn_Login)


        self.verticalLayout_3.addWidget(self.frame)

        self.stackedWidget.addWidget(self.page_login)
        self.page_otp = QWidget()
        self.page_otp.setObjectName(u"page_otp")
        self.verticalLayout_4 = QVBoxLayout(self.page_otp)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.frame_4 = QFrame(self.page_otp)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setFrameShape(QFrame.NoFrame)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_4)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_5 = QFrame(self.frame_4)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setMinimumSize(QSize(210, 210))
        self.frame_5.setMaximumSize(QSize(210, 210))
        self.frame_5.setStyleSheet(u"")
        self.frame_5.setFrameShape(QFrame.NoFrame)
        self.frame_5.setFrameShadow(QFrame.Raised)
        self.verticalLayout_6 = QVBoxLayout(self.frame_5)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.gridLayout = QGridLayout()
        self.gridLayout.setSpacing(0)
        self.gridLayout.setObjectName(u"gridLayout")
        self.gridLayout.setContentsMargins(-1, 25, -1, 0)
        self.label_TOTP_title = QLabel(self.frame_5)
        self.label_TOTP_title.setObjectName(u"label_TOTP_title")
        self.label_TOTP_title.setMinimumSize(QSize(0, 0))
        self.label_TOTP_title.setMaximumSize(QSize(16777215, 16777215))
        font4 = QFont()
        font4.setPointSize(11)
        font4.setBold(True)
        font4.setWeight(75)
        self.label_TOTP_title.setFont(font4)
        self.label_TOTP_title.setStyleSheet(u"background-color:transparent;")
        self.label_TOTP_title.setAlignment(Qt.AlignCenter)

        self.gridLayout.addWidget(self.label_TOTP_title, 0, 0, 1, 1, Qt.AlignVCenter)

        self.label_TOTP = QLabel(self.frame_5)
        self.label_TOTP.setObjectName(u"label_TOTP")
        self.label_TOTP.setMinimumSize(QSize(0, 0))
        self.label_TOTP.setMaximumSize(QSize(16777215, 16777215))
        font5 = QFont()
        font5.setPointSize(30)
        font5.setBold(True)
        font5.setWeight(75)
        self.label_TOTP.setFont(font5)
        self.label_TOTP.setStyleSheet(u"background-color:transparent;")
        self.label_TOTP.setAlignment(Qt.AlignCenter)

        self.gridLayout.addWidget(self.label_TOTP, 1, 0, 1, 1)

        self.label_totp_remaining_time = QLabel(self.frame_5)
        self.label_totp_remaining_time.setObjectName(u"label_totp_remaining_time")
        self.label_totp_remaining_time.setMinimumSize(QSize(0, 0))
        self.label_totp_remaining_time.setMaximumSize(QSize(16777215, 16777215))
        font6 = QFont()
        font6.setPointSize(20)
        font6.setBold(True)
        font6.setWeight(75)
        self.label_totp_remaining_time.setFont(font6)
        self.label_totp_remaining_time.setStyleSheet(u"background-color:transparent;")
        self.label_totp_remaining_time.setAlignment(Qt.AlignCenter)

        self.gridLayout.addWidget(self.label_totp_remaining_time, 2, 0, 1, 1)


        self.verticalLayout_6.addLayout(self.gridLayout)


        self.verticalLayout_5.addWidget(self.frame_5, 0, Qt.AlignHCenter|Qt.AlignVCenter)

        self.frame_6 = QFrame(self.frame_4)
        self.frame_6.setObjectName(u"frame_6")
        sizePolicy1.setHeightForWidth(self.frame_6.sizePolicy().hasHeightForWidth())
        self.frame_6.setSizePolicy(sizePolicy1)
        self.frame_6.setMaximumSize(QSize(16777215, 60))
        self.frame_6.setStyleSheet(u"QPushButton {border-radius:15px}")
        self.frame_6.setFrameShape(QFrame.NoFrame)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_6)
        self.horizontalLayout_3.setSpacing(10)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.Btn_Deny = QPushButton(self.frame_6)
        self.Btn_Deny.setObjectName(u"Btn_Deny")
        sizePolicy4 = QSizePolicy(QSizePolicy.Minimum, QSizePolicy.Expanding)
        sizePolicy4.setHorizontalStretch(0)
        sizePolicy4.setVerticalStretch(0)
        sizePolicy4.setHeightForWidth(self.Btn_Deny.sizePolicy().hasHeightForWidth())
        self.Btn_Deny.setSizePolicy(sizePolicy4)
        self.Btn_Deny.setMaximumSize(QSize(100, 30))
        font7 = QFont()
        font7.setBold(True)
        font7.setWeight(75)
        self.Btn_Deny.setFont(font7)
        self.Btn_Deny.setStyleSheet(u"background-color: #E81E25;")

        self.horizontalLayout_3.addWidget(self.Btn_Deny)

        self.Btn_Approve = QPushButton(self.frame_6)
        self.Btn_Approve.setObjectName(u"Btn_Approve")
        sizePolicy4.setHeightForWidth(self.Btn_Approve.sizePolicy().hasHeightForWidth())
        self.Btn_Approve.setSizePolicy(sizePolicy4)
        self.Btn_Approve.setMaximumSize(QSize(100, 30))
        font8 = QFont()
        font8.setPointSize(9)
        font8.setBold(True)
        font8.setWeight(75)
        self.Btn_Approve.setFont(font8)
        self.Btn_Approve.setStyleSheet(u"QPushButton {background-color: green;}\n"
"QPushButton:hover {background-color:#10A44A;}")

        self.horizontalLayout_3.addWidget(self.Btn_Approve)


        self.verticalLayout_5.addWidget(self.frame_6)


        self.verticalLayout_4.addWidget(self.frame_4, 0, Qt.AlignHCenter)

        self.stackedWidget.addWidget(self.page_otp)

        self.verticalLayout.addWidget(self.stackedWidget)

        self.BottomBar = QFrame(self.bgApp)
        self.BottomBar.setObjectName(u"BottomBar")
        self.BottomBar.setMinimumSize(QSize(0, 30))
        self.BottomBar.setMaximumSize(QSize(16777215, 30))
        self.BottomBar.setFrameShape(QFrame.NoFrame)
        self.BottomBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.BottomBar)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.LoginStateLabel = QLabel(self.BottomBar)
        self.LoginStateLabel.setObjectName(u"LoginStateLabel")
        self.LoginStateLabel.setFont(font1)
        self.LoginStateLabel.setStyleSheet(u"color: #E81E25;")
        self.LoginStateLabel.setMargin(5)

        self.horizontalLayout_4.addWidget(self.LoginStateLabel)

        self.label_version = QLabel(self.BottomBar)
        self.label_version.setObjectName(u"label_version")
        self.label_version.setFont(font1)
        self.label_version.setStyleSheet(u"")
        self.label_version.setAlignment(Qt.AlignRight|Qt.AlignTrailing|Qt.AlignVCenter)
        self.label_version.setMargin(5)

        self.horizontalLayout_4.addWidget(self.label_version)


        self.verticalLayout.addWidget(self.BottomBar)

        LoginScreen.setCentralWidget(self.bgApp)

        self.retranslateUi(LoginScreen)

        self.stackedWidget.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(LoginScreen)
    # setupUi

    def retranslateUi(self, LoginScreen):
        LoginScreen.setWindowTitle(QCoreApplication.translate("LoginScreen", u"MainWindow", None))
        self.label_2.setText(QCoreApplication.translate("LoginScreen", u"WINIGHTER", None))
        self.Btn_Minimize.setText(QCoreApplication.translate("LoginScreen", u"__", None))
        self.Btn_Close.setText(QCoreApplication.translate("LoginScreen", u"X", None))
        self.label_login_state.setText("")
        self.label.setText(QCoreApplication.translate("LoginScreen", u"Login", None))
        self.LineEdit_ID.setPlaceholderText(QCoreApplication.translate("LoginScreen", u"USERNAME", None))
        self.LineEdit_PW.setPlaceholderText(QCoreApplication.translate("LoginScreen", u"PASSWORD", None))
        self.Btn_Login.setText(QCoreApplication.translate("LoginScreen", u"LOGIN", None))
        self.label_TOTP_title.setText(QCoreApplication.translate("LoginScreen", u"ONE TIME PASSWORD", None))
        self.label_TOTP.setText(QCoreApplication.translate("LoginScreen", u"123-456", None))
        self.label_totp_remaining_time.setText(QCoreApplication.translate("LoginScreen", u"10s", None))
        self.Btn_Deny.setText(QCoreApplication.translate("LoginScreen", u"DENY", None))
        self.Btn_Approve.setText(QCoreApplication.translate("LoginScreen", u"APPROVE", None))
        self.LoginStateLabel.setText("")
        self.label_version.setText(QCoreApplication.translate("LoginScreen", u"1.2.0", None))
    # retranslateUi

