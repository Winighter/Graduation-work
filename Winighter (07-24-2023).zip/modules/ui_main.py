# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainsFnMEp.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

from . resources_rc import *

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1100, 600)
        MainWindow.setMinimumSize(QSize(0, 0))
        MainWindow.setStyleSheet(u"")
        self.styleSheet = QWidget(MainWindow)
        self.styleSheet.setObjectName(u"styleSheet")
        self.styleSheet.setStyleSheet(u"/*QWidget*/\n"
"QWidget {\n"
"background-color: #373737;\n"
"font: 10pt \"Segoe UI\";\n"
"}\n"
"\n"
"/*Top Bar*/\n"
"#TopBarMenus .QPushButton{\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	border: none;\n"
"}\n"
"#TopBarMenus .QPushButton:hover {\n"
"background-color: rgb(40, 44, 52);\n"
"}\n"
"#TopBarMenus .QPushButton:pressed{\n"
"	background-color: rgb(193, 193, 193);\n"
"}\n"
"/*Top Bar Close Button*/\n"
"#Btn_Close {\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	border: none;\n"
"}\n"
"#Btn_Close:hover {background-color:#ff0000;}\n"
"#Btn_Close:pressed {background-color:#e50000;}\n"
"\n"
"/*Left*/\n"
"#frame_Left .QPushButton:hover{\n"
"	color: #121212;\n"
"	background-color:#FFFFFF\n"
"}\n"
"#frame_Left .QPushButton:pressed{\n"
"	color: #121212;\n"
"	background-color: rgb(193, 193, 193);\n"
"}\n"
"\n"
"/*Left Top*/\n"
"#frame_Profile .QLabel{\n"
"color:#ffffff\n"
"}\n"
"#frame_Profile .QFrame{\n"
"background-position: center;\n"
"background-repeat:"
                        " no-repeat;\n"
"}\n"
"#frame_Profile .QPushButton{\n"
"	background-position: center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"}\n"
"\n"
"/*Left Main*/\n"
"#frame_LeftMain .QPushButton{\n"
"background-position:center;\n"
"background-repeat: no-repeat;\n"
"border:none;\n"
"color:#ffffff\n"
"}\n"
"#frame_LeftMain .QPushButton:pressed{\n"
"	background-color: rgb(193, 193, 193);\n"
"}\n"
"#lineEdit_Search {\n"
"border:none;\n"
"color: #FFFFFF;\n"
"border-left: 20px solid transparent;\n"
"text-align: left;\n"
"padding-left: 40px;\n"
"}\n"
"\n"
"#LeftToggleMenus .QPushButton {\n"
"	background-position: left center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"	border-left: 20px solid transparent;\n"
"	text-align: left;\n"
"	padding-left: 40px;\n"
"	color:#ffffff;\n"
"}\n"
"\n"
"#frame_LeftMenuPages .QPushButton{\n"
"	background-position: left center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"	border-left: 20px solid transparent;\n"
"	text-align: left;\n"
"	padding-left: 40px"
                        ";\n"
"	color: #FFFFFF;\n"
"}\n"
"\n"
"/*Left Bottom*/\n"
"#frame_LeftBottomMenus .QPushButton{\n"
"	background-position: left center;\n"
"	background-repeat: no-repeat;\n"
"	border:none;\n"
"	border-left: 20px solid transparent;\n"
"	text-align: left;\n"
"	padding-left: 40px;\n"
"	color: #FFFFFF;\n"
"}\n"
"\n"
"/*Extra Left*/\n"
"#frame_extraLeftSettings .QFrame{\n"
"background-color: rgb(184, 184, 184);\n"
"}\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"\n"
"")
        self.verticalLayout = QVBoxLayout(self.styleSheet)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName(u"verticalLayout")
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame_TopBar = QFrame(self.styleSheet)
        self.frame_TopBar.setObjectName(u"frame_TopBar")
        self.frame_TopBar.setMinimumSize(QSize(0, 30))
        self.frame_TopBar.setStyleSheet(u"")
        self.frame_TopBar.setFrameShape(QFrame.NoFrame)
        self.frame_TopBar.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_3 = QHBoxLayout(self.frame_TopBar)
        self.horizontalLayout_3.setSpacing(0)
        self.horizontalLayout_3.setObjectName(u"horizontalLayout_3")
        self.horizontalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.frame_10 = QFrame(self.frame_TopBar)
        self.frame_10.setObjectName(u"frame_10")
        self.frame_10.setFrameShape(QFrame.NoFrame)
        self.frame_10.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_3.addWidget(self.frame_10)

        self.TopBarMenus = QFrame(self.frame_TopBar)
        self.TopBarMenus.setObjectName(u"TopBarMenus")
        self.TopBarMenus.setMaximumSize(QSize(80, 16777215))
        self.TopBarMenus.setStyleSheet(u"")
        self.TopBarMenus.setFrameShape(QFrame.NoFrame)
        self.TopBarMenus.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_2 = QHBoxLayout(self.TopBarMenus)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName(u"horizontalLayout_2")
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.Btn_Minimize = QPushButton(self.TopBarMenus)
        self.Btn_Minimize.setObjectName(u"Btn_Minimize")
        self.Btn_Minimize.setMinimumSize(QSize(40, 30))
        self.Btn_Minimize.setMaximumSize(QSize(40, 30))
        font = QFont()
        font.setFamily(u"Segoe UI")
        font.setPointSize(10)
        font.setBold(False)
        font.setItalic(False)
        font.setWeight(50)
        self.Btn_Minimize.setFont(font)
        self.Btn_Minimize.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-window-minimize.png);")

        self.horizontalLayout_2.addWidget(self.Btn_Minimize)

        self.Btn_MaximizeRestore = QPushButton(self.TopBarMenus)
        self.Btn_MaximizeRestore.setObjectName(u"Btn_MaximizeRestore")
        self.Btn_MaximizeRestore.setMinimumSize(QSize(40, 30))
        self.Btn_MaximizeRestore.setMaximumSize(QSize(40, 30))
        self.Btn_MaximizeRestore.setFont(font)
        self.Btn_MaximizeRestore.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_maximize.png);")

        self.horizontalLayout_2.addWidget(self.Btn_MaximizeRestore)


        self.horizontalLayout_3.addWidget(self.TopBarMenus)

        self.Btn_Close = QPushButton(self.frame_TopBar)
        self.Btn_Close.setObjectName(u"Btn_Close")
        self.Btn_Close.setMinimumSize(QSize(40, 30))
        self.Btn_Close.setMaximumSize(QSize(40, 30))
        self.Btn_Close.setFont(font)
        self.Btn_Close.setStyleSheet(u"background-image: url(:/icons/images/icons/icon_close.png);\n"
"")

        self.horizontalLayout_3.addWidget(self.Btn_Close)


        self.verticalLayout.addWidget(self.frame_TopBar)

        self.frame = QFrame(self.styleSheet)
        self.frame.setObjectName(u"frame")
        self.frame.setFrameShape(QFrame.NoFrame)
        self.frame.setFrameShadow(QFrame.Raised)
        self.horizontalLayout = QHBoxLayout(self.frame)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName(u"horizontalLayout")
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.frame_Left = QFrame(self.frame)
        self.frame_Left.setObjectName(u"frame_Left")
        self.frame_Left.setMinimumSize(QSize(60, 0))
        self.frame_Left.setMaximumSize(QSize(60, 16777215))
        self.frame_Left.setStyleSheet(u"")
        self.frame_Left.setFrameShape(QFrame.NoFrame)
        self.frame_Left.setFrameShadow(QFrame.Raised)
        self.verticalLayout_2 = QVBoxLayout(self.frame_Left)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName(u"verticalLayout_2")
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.frame_Profile = QFrame(self.frame_Left)
        self.frame_Profile.setObjectName(u"frame_Profile")
        self.frame_Profile.setMinimumSize(QSize(0, 60))
        self.frame_Profile.setMaximumSize(QSize(16777215, 60))
        self.frame_Profile.setStyleSheet(u"QPushButton {\n"
"background-position: center;\n"
"}\n"
"")
        self.frame_Profile.setFrameShape(QFrame.NoFrame)
        self.frame_Profile.setFrameShadow(QFrame.Raised)
        self.frame_ProfileUser = QFrame(self.frame_Profile)
        self.frame_ProfileUser.setObjectName(u"frame_ProfileUser")
        self.frame_ProfileUser.setGeometry(QRect(0, 0, 60, 60))
        self.frame_ProfileUser.setMinimumSize(QSize(0, 0))
        self.frame_ProfileUser.setMaximumSize(QSize(16777215, 16777215))
        self.frame_ProfileUser.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-user.png);")
        self.frame_ProfileUser.setFrameShape(QFrame.NoFrame)
        self.frame_ProfileUser.setFrameShadow(QFrame.Raised)
        self.label_Email = QLabel(self.frame_Profile)
        self.label_Email.setObjectName(u"label_Email")
        self.label_Email.setGeometry(QRect(60, 30, 160, 30))
        self.label_Email.setMinimumSize(QSize(0, 30))
        self.label_Email.setMaximumSize(QSize(160, 16777215))
        self.frame_6 = QFrame(self.frame_Profile)
        self.frame_6.setObjectName(u"frame_6")
        self.frame_6.setGeometry(QRect(61, 1, 161, 30))
        self.frame_6.setMinimumSize(QSize(0, 0))
        self.frame_6.setFrameShape(QFrame.NoFrame)
        self.frame_6.setFrameShadow(QFrame.Raised)
        self.Btn_ProfileSetting = QPushButton(self.frame_6)
        self.Btn_ProfileSetting.setObjectName(u"Btn_ProfileSetting")
        self.Btn_ProfileSetting.setGeometry(QRect(130, 0, 30, 30))
        sizePolicy = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Btn_ProfileSetting.sizePolicy().hasHeightForWidth())
        self.Btn_ProfileSetting.setSizePolicy(sizePolicy)
        self.Btn_ProfileSetting.setMinimumSize(QSize(0, 0))
        self.Btn_ProfileSetting.setMaximumSize(QSize(30, 30))
        self.Btn_ProfileSetting.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-options.png);")
        self.label_Name = QLabel(self.frame_6)
        self.label_Name.setObjectName(u"label_Name")
        self.label_Name.setGeometry(QRect(0, 0, 130, 30))
        self.label_Name.setMaximumSize(QSize(160, 16777215))
        self.label_Name.setFont(font)

        self.verticalLayout_2.addWidget(self.frame_Profile)

        self.frame_LeftMain = QFrame(self.frame_Left)
        self.frame_LeftMain.setObjectName(u"frame_LeftMain")
        self.frame_LeftMain.setFrameShape(QFrame.NoFrame)
        self.frame_LeftMain.setFrameShadow(QFrame.Raised)
        self.verticalLayout_12 = QVBoxLayout(self.frame_LeftMain)
        self.verticalLayout_12.setSpacing(0)
        self.verticalLayout_12.setObjectName(u"verticalLayout_12")
        self.verticalLayout_12.setContentsMargins(0, 0, 0, 0)
        self.LeftTabMenus = QFrame(self.frame_LeftMain)
        self.LeftTabMenus.setObjectName(u"LeftTabMenus")
        self.LeftTabMenus.setMinimumSize(QSize(220, 40))
        self.LeftTabMenus.setFrameShape(QFrame.NoFrame)
        self.LeftTabMenus.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_5 = QHBoxLayout(self.LeftTabMenus)
        self.horizontalLayout_5.setSpacing(0)
        self.horizontalLayout_5.setObjectName(u"horizontalLayout_5")
        self.horizontalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.frame_LeftMenuEmpty = QFrame(self.LeftTabMenus)
        self.frame_LeftMenuEmpty.setObjectName(u"frame_LeftMenuEmpty")
        self.frame_LeftMenuEmpty.setMinimumSize(QSize(60, 0))
        self.frame_LeftMenuEmpty.setMaximumSize(QSize(0, 16777215))
        self.frame_LeftMenuEmpty.setStyleSheet(u"")
        self.frame_LeftMenuEmpty.setFrameShape(QFrame.NoFrame)
        self.frame_LeftMenuEmpty.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_5.addWidget(self.frame_LeftMenuEmpty)

        self.Btn_LeftMenuTab_1 = QPushButton(self.LeftTabMenus)
        self.Btn_LeftMenuTab_1.setObjectName(u"Btn_LeftMenuTab_1")
        self.Btn_LeftMenuTab_1.setMinimumSize(QSize(80, 40))
        self.Btn_LeftMenuTab_1.setMaximumSize(QSize(16777215, 16777215))

        self.horizontalLayout_5.addWidget(self.Btn_LeftMenuTab_1)

        self.Btn_LeftMenuTab_2 = QPushButton(self.LeftTabMenus)
        self.Btn_LeftMenuTab_2.setObjectName(u"Btn_LeftMenuTab_2")
        self.Btn_LeftMenuTab_2.setMinimumSize(QSize(80, 40))

        self.horizontalLayout_5.addWidget(self.Btn_LeftMenuTab_2)


        self.verticalLayout_12.addWidget(self.LeftTabMenus, 0, Qt.AlignRight)

        self.frame_LeftMenuPages = QFrame(self.frame_LeftMain)
        self.frame_LeftMenuPages.setObjectName(u"frame_LeftMenuPages")
        self.frame_LeftMenuPages.setStyleSheet(u"")
        self.frame_LeftMenuPages.setFrameShape(QFrame.NoFrame)
        self.frame_LeftMenuPages.setFrameShadow(QFrame.Raised)
        self.verticalLayout_5 = QVBoxLayout(self.frame_LeftMenuPages)
        self.verticalLayout_5.setSpacing(0)
        self.verticalLayout_5.setObjectName(u"verticalLayout_5")
        self.verticalLayout_5.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget_Left = QStackedWidget(self.frame_LeftMenuPages)
        self.stackedWidget_Left.setObjectName(u"stackedWidget_Left")
        self.stackedWidget_Left.setStyleSheet(u"")
        self.page_LeftMenu_2 = QWidget()
        self.page_LeftMenu_2.setObjectName(u"page_LeftMenu_2")
        self.verticalLayout_6 = QVBoxLayout(self.page_LeftMenu_2)
        self.verticalLayout_6.setSpacing(0)
        self.verticalLayout_6.setObjectName(u"verticalLayout_6")
        self.verticalLayout_6.setContentsMargins(0, 0, 0, 0)
        self.frame_8 = QFrame(self.page_LeftMenu_2)
        self.frame_8.setObjectName(u"frame_8")
        self.frame_8.setFrameShape(QFrame.NoFrame)
        self.frame_8.setFrameShadow(QFrame.Raised)
        self.verticalLayout_14 = QVBoxLayout(self.frame_8)
        self.verticalLayout_14.setSpacing(0)
        self.verticalLayout_14.setObjectName(u"verticalLayout_14")
        self.verticalLayout_14.setContentsMargins(0, 0, 0, 0)
        self.pushButton_6 = QPushButton(self.frame_8)
        self.pushButton_6.setObjectName(u"pushButton_6")
        sizePolicy1 = QSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        sizePolicy1.setHorizontalStretch(0)
        sizePolicy1.setVerticalStretch(0)
        sizePolicy1.setHeightForWidth(self.pushButton_6.sizePolicy().hasHeightForWidth())
        self.pushButton_6.setSizePolicy(sizePolicy1)
        self.pushButton_6.setMinimumSize(QSize(0, 40))
        self.pushButton_6.setMaximumSize(QSize(16777215, 16777215))
        self.pushButton_6.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-external-link.png);")

        self.verticalLayout_14.addWidget(self.pushButton_6)

        self.pushButton_7 = QPushButton(self.frame_8)
        self.pushButton_7.setObjectName(u"pushButton_7")
        sizePolicy1.setHeightForWidth(self.pushButton_7.sizePolicy().hasHeightForWidth())
        self.pushButton_7.setSizePolicy(sizePolicy1)
        self.pushButton_7.setMinimumSize(QSize(0, 40))
        self.pushButton_7.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-view-stream.png);")

        self.verticalLayout_14.addWidget(self.pushButton_7)


        self.verticalLayout_6.addWidget(self.frame_8, 0, Qt.AlignTop)

        self.stackedWidget_Left.addWidget(self.page_LeftMenu_2)
        self.page_LeftMenu_1 = QWidget()
        self.page_LeftMenu_1.setObjectName(u"page_LeftMenu_1")
        self.verticalLayout_3 = QVBoxLayout(self.page_LeftMenu_1)
        self.verticalLayout_3.setSpacing(0)
        self.verticalLayout_3.setObjectName(u"verticalLayout_3")
        self.verticalLayout_3.setContentsMargins(0, 0, 0, 0)
        self.LeftMainMenus = QFrame(self.page_LeftMenu_1)
        self.LeftMainMenus.setObjectName(u"LeftMainMenus")
        self.LeftMainMenus.setFrameShape(QFrame.NoFrame)
        self.LeftMainMenus.setFrameShadow(QFrame.Raised)
        self.verticalLayout_4 = QVBoxLayout(self.LeftMainMenus)
        self.verticalLayout_4.setSpacing(0)
        self.verticalLayout_4.setObjectName(u"verticalLayout_4")
        self.verticalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.Btn_Home = QPushButton(self.LeftMainMenus)
        self.Btn_Home.setObjectName(u"Btn_Home")
        sizePolicy1.setHeightForWidth(self.Btn_Home.sizePolicy().hasHeightForWidth())
        self.Btn_Home.setSizePolicy(sizePolicy1)
        self.Btn_Home.setMinimumSize(QSize(0, 40))
        self.Btn_Home.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-home.png);")

        self.verticalLayout_4.addWidget(self.Btn_Home)

        self.Btn_myTasks = QPushButton(self.LeftMainMenus)
        self.Btn_myTasks.setObjectName(u"Btn_myTasks")
        sizePolicy1.setHeightForWidth(self.Btn_myTasks.sizePolicy().hasHeightForWidth())
        self.Btn_myTasks.setSizePolicy(sizePolicy1)
        self.Btn_myTasks.setMinimumSize(QSize(0, 40))
        self.Btn_myTasks.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-task.png);")

        self.verticalLayout_4.addWidget(self.Btn_myTasks)

        self.pushButton_4 = QPushButton(self.LeftMainMenus)
        self.pushButton_4.setObjectName(u"pushButton_4")
        sizePolicy1.setHeightForWidth(self.pushButton_4.sizePolicy().hasHeightForWidth())
        self.pushButton_4.setSizePolicy(sizePolicy1)
        self.pushButton_4.setMinimumSize(QSize(0, 40))
        self.pushButton_4.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-ban.png);")

        self.verticalLayout_4.addWidget(self.pushButton_4)

        self.pushButton_5 = QPushButton(self.LeftMainMenus)
        self.pushButton_5.setObjectName(u"pushButton_5")
        sizePolicy1.setHeightForWidth(self.pushButton_5.sizePolicy().hasHeightForWidth())
        self.pushButton_5.setSizePolicy(sizePolicy1)
        self.pushButton_5.setMinimumSize(QSize(0, 40))
        self.pushButton_5.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-ban.png);")

        self.verticalLayout_4.addWidget(self.pushButton_5)

        self.Btn_Developer = QPushButton(self.LeftMainMenus)
        self.Btn_Developer.setObjectName(u"Btn_Developer")
        sizePolicy1.setHeightForWidth(self.Btn_Developer.sizePolicy().hasHeightForWidth())
        self.Btn_Developer.setSizePolicy(sizePolicy1)
        self.Btn_Developer.setMinimumSize(QSize(0, 40))
        self.Btn_Developer.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-terminal.png);")

        self.verticalLayout_4.addWidget(self.Btn_Developer)


        self.verticalLayout_3.addWidget(self.LeftMainMenus, 0, Qt.AlignTop)

        self.stackedWidget_Left.addWidget(self.page_LeftMenu_1)

        self.verticalLayout_5.addWidget(self.stackedWidget_Left)


        self.verticalLayout_12.addWidget(self.frame_LeftMenuPages)


        self.verticalLayout_2.addWidget(self.frame_LeftMain)

        self.frame_LeftBottomMenus = QFrame(self.frame_Left)
        self.frame_LeftBottomMenus.setObjectName(u"frame_LeftBottomMenus")
        self.frame_LeftBottomMenus.setMinimumSize(QSize(0, 0))
        self.frame_LeftBottomMenus.setMaximumSize(QSize(16777215, 16777215))
        self.frame_LeftBottomMenus.setStyleSheet(u"")
        self.frame_LeftBottomMenus.setFrameShape(QFrame.NoFrame)
        self.frame_LeftBottomMenus.setFrameShadow(QFrame.Raised)
        self.verticalLayout_7 = QVBoxLayout(self.frame_LeftBottomMenus)
        self.verticalLayout_7.setSpacing(0)
        self.verticalLayout_7.setObjectName(u"verticalLayout_7")
        self.verticalLayout_7.setContentsMargins(0, 0, 0, 0)
        self.Btn_Notifications = QPushButton(self.frame_LeftBottomMenus)
        self.Btn_Notifications.setObjectName(u"Btn_Notifications")
        sizePolicy1.setHeightForWidth(self.Btn_Notifications.sizePolicy().hasHeightForWidth())
        self.Btn_Notifications.setSizePolicy(sizePolicy1)
        self.Btn_Notifications.setMinimumSize(QSize(0, 40))
        self.Btn_Notifications.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-bell.png);")

        self.verticalLayout_7.addWidget(self.Btn_Notifications)

        self.Btn_Support = QPushButton(self.frame_LeftBottomMenus)
        self.Btn_Support.setObjectName(u"Btn_Support")
        sizePolicy1.setHeightForWidth(self.Btn_Support.sizePolicy().hasHeightForWidth())
        self.Btn_Support.setSizePolicy(sizePolicy1)
        self.Btn_Support.setMinimumSize(QSize(0, 40))
        self.Btn_Support.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-headphones.png);")

        self.verticalLayout_7.addWidget(self.Btn_Support)

        self.Btn_Settings = QPushButton(self.frame_LeftBottomMenus)
        self.Btn_Settings.setObjectName(u"Btn_Settings")
        sizePolicy1.setHeightForWidth(self.Btn_Settings.sizePolicy().hasHeightForWidth())
        self.Btn_Settings.setSizePolicy(sizePolicy1)
        self.Btn_Settings.setMinimumSize(QSize(0, 40))
        self.Btn_Settings.setLayoutDirection(Qt.LeftToRight)
        self.Btn_Settings.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-settings.png);\n"
"")

        self.verticalLayout_7.addWidget(self.Btn_Settings)


        self.verticalLayout_2.addWidget(self.frame_LeftBottomMenus)


        self.horizontalLayout.addWidget(self.frame_Left)

        self.frame_extraLeftSettings = QFrame(self.frame)
        self.frame_extraLeftSettings.setObjectName(u"frame_extraLeftSettings")
        self.frame_extraLeftSettings.setMinimumSize(QSize(0, 0))
        self.frame_extraLeftSettings.setMaximumSize(QSize(0, 16777215))
        self.frame_extraLeftSettings.setStyleSheet(u"")
        self.frame_extraLeftSettings.setFrameShape(QFrame.NoFrame)
        self.frame_extraLeftSettings.setFrameShadow(QFrame.Raised)
        self.verticalLayout_13 = QVBoxLayout(self.frame_extraLeftSettings)
        self.verticalLayout_13.setSpacing(0)
        self.verticalLayout_13.setObjectName(u"verticalLayout_13")
        self.verticalLayout_13.setContentsMargins(0, 0, 0, 0)
        self.frame_3 = QFrame(self.frame_extraLeftSettings)
        self.frame_3.setObjectName(u"frame_3")
        self.frame_3.setMinimumSize(QSize(0, 0))
        self.frame_3.setMaximumSize(QSize(16777215, 60))
        self.frame_3.setFrameShape(QFrame.NoFrame)
        self.frame_3.setFrameShadow(QFrame.Raised)

        self.verticalLayout_13.addWidget(self.frame_3)

        self.frame_11 = QFrame(self.frame_extraLeftSettings)
        self.frame_11.setObjectName(u"frame_11")
        self.frame_11.setFrameShape(QFrame.NoFrame)
        self.frame_11.setFrameShadow(QFrame.Raised)

        self.verticalLayout_13.addWidget(self.frame_11)


        self.horizontalLayout.addWidget(self.frame_extraLeftSettings)

        self.frame_Main = QFrame(self.frame)
        self.frame_Main.setObjectName(u"frame_Main")
        self.frame_Main.setStyleSheet(u"")
        self.frame_Main.setFrameShape(QFrame.NoFrame)
        self.frame_Main.setFrameShadow(QFrame.Raised)
        self.verticalLayout_8 = QVBoxLayout(self.frame_Main)
        self.verticalLayout_8.setSpacing(0)
        self.verticalLayout_8.setObjectName(u"verticalLayout_8")
        self.verticalLayout_8.setContentsMargins(0, 0, 0, 0)
        self.frame_MainContent = QFrame(self.frame_Main)
        self.frame_MainContent.setObjectName(u"frame_MainContent")
        self.frame_MainContent.setFrameShape(QFrame.NoFrame)
        self.frame_MainContent.setFrameShadow(QFrame.Raised)
        self.horizontalLayout_4 = QHBoxLayout(self.frame_MainContent)
        self.horizontalLayout_4.setSpacing(0)
        self.horizontalLayout_4.setObjectName(u"horizontalLayout_4")
        self.horizontalLayout_4.setContentsMargins(0, 0, 0, 0)
        self.frame_Content = QFrame(self.frame_MainContent)
        self.frame_Content.setObjectName(u"frame_Content")
        self.frame_Content.setFrameShape(QFrame.NoFrame)
        self.frame_Content.setFrameShadow(QFrame.Raised)
        self.verticalLayout_9 = QVBoxLayout(self.frame_Content)
        self.verticalLayout_9.setSpacing(0)
        self.verticalLayout_9.setObjectName(u"verticalLayout_9")
        self.verticalLayout_9.setContentsMargins(0, 0, 0, 0)
        self.stackedWidget_Main = QStackedWidget(self.frame_Content)
        self.stackedWidget_Main.setObjectName(u"stackedWidget_Main")
        self.page_Home = QWidget()
        self.page_Home.setObjectName(u"page_Home")
        self.verticalLayout_10 = QVBoxLayout(self.page_Home)
        self.verticalLayout_10.setSpacing(0)
        self.verticalLayout_10.setObjectName(u"verticalLayout_10")
        self.verticalLayout_10.setContentsMargins(0, 0, 0, 0)
        self.Home = QFrame(self.page_Home)
        self.Home.setObjectName(u"Home")
        self.Home.setFrameShape(QFrame.StyledPanel)
        self.Home.setFrameShadow(QFrame.Raised)

        self.verticalLayout_10.addWidget(self.Home)

        self.stackedWidget_Main.addWidget(self.page_Home)
        self.page_Home_2 = QWidget()
        self.page_Home_2.setObjectName(u"page_Home_2")
        self.verticalLayout_11 = QVBoxLayout(self.page_Home_2)
        self.verticalLayout_11.setSpacing(0)
        self.verticalLayout_11.setObjectName(u"verticalLayout_11")
        self.verticalLayout_11.setContentsMargins(0, 0, 0, 0)
        self.frame_9 = QFrame(self.page_Home_2)
        self.frame_9.setObjectName(u"frame_9")
        self.frame_9.setFrameShape(QFrame.StyledPanel)
        self.frame_9.setFrameShadow(QFrame.Raised)
        self.lineEdit_Search = QLineEdit(self.frame_9)
        self.lineEdit_Search.setObjectName(u"lineEdit_Search")
        self.lineEdit_Search.setGeometry(QRect(320, 150, 220, 40))
        sizePolicy1.setHeightForWidth(self.lineEdit_Search.sizePolicy().hasHeightForWidth())
        self.lineEdit_Search.setSizePolicy(sizePolicy1)
        self.lineEdit_Search.setMinimumSize(QSize(0, 40))
        self.lineEdit_Search.setMaximumSize(QSize(16777215, 40))
        self.lineEdit_Search.setStyleSheet(u"background-image: url(:/icons/images/icons/cil-magnifying-glass.png);")

        self.verticalLayout_11.addWidget(self.frame_9)

        self.stackedWidget_Main.addWidget(self.page_Home_2)
        self.page_Home_3 = QWidget()
        self.page_Home_3.setObjectName(u"page_Home_3")
        self.frame_2 = QFrame(self.page_Home_3)
        self.frame_2.setObjectName(u"frame_2")
        self.frame_2.setGeometry(QRect(350, 190, 120, 80))
        self.frame_2.setFrameShape(QFrame.NoFrame)
        self.frame_2.setFrameShadow(QFrame.Raised)
        self.stackedWidget_Main.addWidget(self.page_Home_3)
        self.page_Home_4 = QWidget()
        self.page_Home_4.setObjectName(u"page_Home_4")
        self.frame_4 = QFrame(self.page_Home_4)
        self.frame_4.setObjectName(u"frame_4")
        self.frame_4.setGeometry(QRect(350, 120, 120, 80))
        self.frame_4.setFrameShape(QFrame.NoFrame)
        self.frame_4.setFrameShadow(QFrame.Raised)
        self.stackedWidget_Main.addWidget(self.page_Home_4)
        self.page_Home_5 = QWidget()
        self.page_Home_5.setObjectName(u"page_Home_5")
        self.frame_5 = QFrame(self.page_Home_5)
        self.frame_5.setObjectName(u"frame_5")
        self.frame_5.setGeometry(QRect(400, 260, 120, 80))
        self.frame_5.setFrameShape(QFrame.NoFrame)
        self.frame_5.setFrameShadow(QFrame.Raised)
        self.stackedWidget_Main.addWidget(self.page_Home_5)
        self.page_DDE = QWidget()
        self.page_DDE.setObjectName(u"page_DDE")
        self.verticalLayout_15 = QVBoxLayout(self.page_DDE)
        self.verticalLayout_15.setSpacing(0)
        self.verticalLayout_15.setObjectName(u"verticalLayout_15")
        self.verticalLayout_15.setContentsMargins(0, 0, 0, 0)
        self.frame_dde = QFrame(self.page_DDE)
        self.frame_dde.setObjectName(u"frame_dde")
        self.frame_dde.setFrameShape(QFrame.NoFrame)
        self.frame_dde.setFrameShadow(QFrame.Raised)
        self.verticalLayout_16 = QVBoxLayout(self.frame_dde)
        self.verticalLayout_16.setSpacing(0)
        self.verticalLayout_16.setObjectName(u"verticalLayout_16")
        self.verticalLayout_16.setContentsMargins(10, 10, 10, 10)
        self.tableWidget = QTableWidget(self.frame_dde)
        if (self.tableWidget.columnCount() < 4):
            self.tableWidget.setColumnCount(4)
        __qtablewidgetitem = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        __qtablewidgetitem1 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        if (self.tableWidget.rowCount() < 4):
            self.tableWidget.setRowCount(4)
        __qtablewidgetitem4 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(0, __qtablewidgetitem4)
        __qtablewidgetitem5 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(1, __qtablewidgetitem5)
        __qtablewidgetitem6 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(2, __qtablewidgetitem6)
        __qtablewidgetitem7 = QTableWidgetItem()
        self.tableWidget.setVerticalHeaderItem(3, __qtablewidgetitem7)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setStyleSheet(u"")
        self.tableWidget.setFrameShape(QFrame.NoFrame)

        self.verticalLayout_16.addWidget(self.tableWidget)


        self.verticalLayout_15.addWidget(self.frame_dde)

        self.stackedWidget_Main.addWidget(self.page_DDE)

        self.verticalLayout_9.addWidget(self.stackedWidget_Main)


        self.horizontalLayout_4.addWidget(self.frame_Content)

        self.frame_extraRight_to_be_later = QFrame(self.frame_MainContent)
        self.frame_extraRight_to_be_later.setObjectName(u"frame_extraRight_to_be_later")
        self.frame_extraRight_to_be_later.setMaximumSize(QSize(0, 16777215))
        self.frame_extraRight_to_be_later.setFrameShape(QFrame.NoFrame)
        self.frame_extraRight_to_be_later.setFrameShadow(QFrame.Raised)

        self.horizontalLayout_4.addWidget(self.frame_extraRight_to_be_later)


        self.verticalLayout_8.addWidget(self.frame_MainContent)


        self.horizontalLayout.addWidget(self.frame_Main)


        self.verticalLayout.addWidget(self.frame)

        MainWindow.setCentralWidget(self.styleSheet)

        self.retranslateUi(MainWindow)

        self.stackedWidget_Left.setCurrentIndex(1)
        self.stackedWidget_Main.setCurrentIndex(0)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.Btn_Minimize.setText("")
        self.Btn_MaximizeRestore.setText("")
        self.Btn_Close.setText("")
        self.label_Email.setText(QCoreApplication.translate("MainWindow", u"abc1234@email.com", None))
        self.Btn_ProfileSetting.setText("")
        self.label_Name.setText(QCoreApplication.translate("MainWindow", u"Who Who", None))
        self.Btn_LeftMenuTab_1.setText(QCoreApplication.translate("MainWindow", u"Tab", None))
        self.Btn_LeftMenuTab_2.setText(QCoreApplication.translate("MainWindow", u"Tab", None))
        self.pushButton_6.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.pushButton_7.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_Home.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.Btn_myTasks.setText(QCoreApplication.translate("MainWindow", u"My Tasks", None))
        self.pushButton_4.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.pushButton_5.setText(QCoreApplication.translate("MainWindow", u"To be later", None))
        self.Btn_Developer.setText(QCoreApplication.translate("MainWindow", u"Developer Options", None))
        self.Btn_Notifications.setText(QCoreApplication.translate("MainWindow", u"Notifications", None))
        self.Btn_Support.setText(QCoreApplication.translate("MainWindow", u"Support", None))
        self.Btn_Settings.setText(QCoreApplication.translate("MainWindow", u"Settings", None))
        self.lineEdit_Search.setText(QCoreApplication.translate("MainWindow", u"1234", None))
        self.lineEdit_Search.setPlaceholderText(QCoreApplication.translate("MainWindow", u"Search", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem3 = self.tableWidget.horizontalHeaderItem(3)
        ___qtablewidgetitem3.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \ud589", None));
        ___qtablewidgetitem4 = self.tableWidget.verticalHeaderItem(0)
        ___qtablewidgetitem4.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem5 = self.tableWidget.verticalHeaderItem(1)
        ___qtablewidgetitem5.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem6 = self.tableWidget.verticalHeaderItem(2)
        ___qtablewidgetitem6.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
        ___qtablewidgetitem7 = self.tableWidget.verticalHeaderItem(3)
        ___qtablewidgetitem7.setText(QCoreApplication.translate("MainWindow", u"\uc0c8 \uc5f4", None));
    # retranslateUi

