from main import *

STATE = False
class Ui_Functions(MainWindow):

    def uiDefaultSet(self):

        # Standard Title Bar
        self.setWindowFlags(Qt.FramelessWindowHint)
        self.setAttribute(Qt.WA_TranslucentBackground)

        # Minimize Button
        self.ui.Btn_Minimize.clicked.connect(lambda:self.showMinimized())
        
        # Maximize & Resotre Button
        self.ui.Btn_MaximizeRestore.clicked.connect(lambda:Ui_Functions.maximize_restore(self))
        
        # Minimize Button
        self.ui.Btn_Close.clicked.connect(lambda:self.close())
        
        
    # Maximize & Resotre Function
    def maximize_restore(self):
        global STATE
        status = STATE
        if status == False:
            STATE = True
            self.showMaximized()
            self.ui.Btn_MaximizeRestore.setStyleSheet('background-image: url(:/icons/images/icons/cil-window-restore.png);')
        else:
            STATE = False
            self.showNormal()
            self.ui.Btn_MaximizeRestore.setStyleSheet('background-image: url(:/icons/images/icons/icon_maximize.png);')
            
    # Left Toggle Menu
    def toggleMenu(self, enable, widthExtend):
        if enable:
            width = self.ui.frame_Left.width()

            if width == 60:
                widthExtended = widthExtend
            else:
                widthExtended = widthExtend

            self.animation = QPropertyAnimation(self.ui.frame_Left, b"minimumWidth")
            self.animation.setDuration(200)
            self.animation.setStartValue(width)
            self.animation.setEndValue(widthExtended)
            self.animation.setEasingCurve(QEasingCurve.InOutQuart)
            self.animation.start()
   
   
    # Toggle Extra Left Menu
    def toggleExtraLeft(self, enable):
        if enable:
            width = self.ui.frame_extraLeftSettings.width()
            standard = 0
            maxExtend = 220
            
            if width == 0:
                widthExtended = maxExtend
            else:
                widthExtended = standard

            self.animation = QPropertyAnimation(self.ui.frame_extraLeftSettings, b"minimumWidth")
            self.animation.setDuration(200)
            self.animation.setStartValue(width)
            self.animation.setEndValue(widthExtended)
            self.animation.setEasingCurve(QEasingCurve.InOutQuart)
            self.animation.start()
    
        
    def open_file(self):
        fileName = QFileDialog.getOpenFileNames(self, "Open file", "./")

    def add_save(self):
        FileSave = QFileDialog.getSaveFileNames(self, "Save file", "./")

    def find_folder(self):
        FileFolder = QFileDialog.getExistingDirectory(self, "Find Folder")  
        

    def uiLoginDefinitions(self):
        self.setWindowFlags(Qt.FramelessWindowHint)

        def moveWindow(event):
            if event.buttons() == Qt.LeftButton:
                self.move(self.pos() + event.globalPos() - self.dragPos)
                self.dragPos = event.globalPos()
                # event.accept()
        self.login_ui.bgApp.mouseMoveEvent = moveWindow
        
        # MINIMIZE
        self.login_ui.Btn_Minimize.clicked.connect(lambda: self.showMinimized())

        # CLOSE APPLICATION
        self.login_ui.Btn_Close.clicked.connect(lambda: self.close())